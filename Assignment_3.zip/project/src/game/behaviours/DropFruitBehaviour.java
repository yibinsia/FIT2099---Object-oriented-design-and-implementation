package game.behaviours;

import edu.monash.fit2099.engine.positions.Location;
import game.grounds.Inheritree;
import game.spawners.Spawner;
import java.util.Random;
/**
 * Implements the PlantBehaviour interface to enable fruit dropping behavior for trees.
 * This class is responsible for managing the chance and execution of fruit dropping events.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public class DropFruitBehaviour implements PlantBehaviour{
    /**
     * The spawner responsible for creating and placing fruits.
     */
    private Spawner fruitSpawner;
    /**
     * The probability of a fruit dropping event occurring.
     */
    private double dropChance;
    /**
     * Random number generator used to determine drop chance.
     */
    private Random random = new Random();
    /**
     * Constructor for DropFruitBehaviour.
     * Initializes the fruit spawner and the chance of dropping a fruit.
     *
     * @param fruitSpawner The spawner responsible for creating and placing fruits.
     * @param dropChance The probability of a fruit dropping event occurring.
     */
    public DropFruitBehaviour(Spawner fruitSpawner, double dropChance){
        this.fruitSpawner = fruitSpawner;
        this.dropChance = dropChance;
    }
    /**
     * Executes the fruit dropping behavior for the given tree at the specified location.
     * The behavior checks the drop chance and spawns a fruit if the condition is met.
     *
     * @param tree The tree on which the behavior is executed.
     * @param location The location where the behavior is executed.
     */
    @Override
    public void execute(Inheritree tree, Location location){
        if (random.nextFloat() <= dropChance){
            fruitSpawner.spawn(location);
        }
    }
}
