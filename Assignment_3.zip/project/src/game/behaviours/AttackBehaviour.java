package game.behaviours;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;
import game.abilities.Status;

/**
 * A behaviour that allows an actor to attack adjacent actors based on certain conditions.
 * Specifically, this behaviour facilitates attacks on adjacent actors if they are marked as hostile.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public class AttackBehaviour implements Behaviour{

    /**
     * Determines an action for an actor based on its surroundings.
     * If an adjacent actor is found and is hostile, this behaviour will return an attack action against that actor.
     *
     * @param actor the actor exhibiting this behaviour
     * @param map   the game map where the actor is located
     * @return an AttackAction if a hostile actor is adjacent, null otherwise
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);

        for (Exit exit : here.getExits()) {
            Location next = exit.getDestination();
            if (next.containsAnActor()) {
                Actor other = next.getActor();
                if (other.hasCapability(Status.HOSTILE_TO_ENEMY)) {
                    // Attack only if the other actor is a player
                    return new AttackAction(other, exit.getName(), actor.getIntrinsicWeapon());
                }
            }
        }
        return null;
    }

}
