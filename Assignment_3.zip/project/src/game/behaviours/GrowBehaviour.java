package game.behaviours;
import game.grounds.Inheritree;
import edu.monash.fit2099.engine.positions.Location;
/**
 * Implements the PlantBehaviour interface to enable growth behavior for trees.
 * This class is responsible for managing the growth stages of trees.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public class GrowBehaviour implements PlantBehaviour{
    /**
     * The age at which the tree transitions to the next stage.
     */
    private int growthAge;
    /**
     * The next stage of the tree after growth.
     */
    private Inheritree nextStage;
    /**
     * Constructor for GrowBehaviour.
     * Initializes the growth age and the next stage of the tree.
     *
     * @param growthAge The age at which the tree transitions to the next stage.
     * @param nextStage The next stage of the tree after growth.
     */
    public GrowBehaviour(int growthAge, Inheritree nextStage){
        this.growthAge = growthAge;
        this.nextStage = nextStage;
    }
    /**
     * Executes the growth behavior for the given tree at the specified location.
     * The behavior checks the tree's age and transitions it to the next stage if the condition is met.
     *
     * @param tree The tree on which the behavior is executed.
     * @param location The location where the behavior is executed.
     */
    @Override
    public void execute(Inheritree tree, Location location){
        if (tree.getAge() >= growthAge){
            location.setGround(nextStage);
        }
    }
}
