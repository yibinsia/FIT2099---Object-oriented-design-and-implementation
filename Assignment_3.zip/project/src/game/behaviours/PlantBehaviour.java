package game.behaviours;

import edu.monash.fit2099.engine.positions.Location;
import game.grounds.Inheritree;
/**
 * Interface defining behaviors for plants in the game environment.
 * Implementations of this interface are responsible for executing specific actions related to plant growth and interactions.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public interface PlantBehaviour {
    /**
     * Executes a specific behavior for the given tree at the specified location.
     *
     * @param tree The tree on which the behavior is executed.
     * @param location The location where the behavior is executed.
     */
    void execute(Inheritree tree, Location location);
}
