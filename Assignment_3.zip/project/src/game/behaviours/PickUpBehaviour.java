package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.items.PickUpAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;

import java.util.Random;

/**
 * Behaviour for an Actor to pick up items from ground if the location of the actor contains items
 * This class defines the logic for actor to pick up an item at current location
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun
 */
public class PickUpBehaviour implements Behaviour {
    Random random = new Random();

    /**
     * Determines an action for an actor based on its surroundings.
     * If an item is found, this behaviour will return a pickup action.
     *
     * @param actor the actor exhibiting this behaviour
     * @param map   the game map where the actor is located
     * @return an PickUpAction if a hostile actor is adjacent, null otherwise
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        Location here = map.locationOf(actor);

        if (!here.getItems().isEmpty()){
            int randomIndex = random.nextInt(here.getItems().size());
            return here.getItems().get(randomIndex).getPickUpAction(actor);
        }
        return null;
    }
}
