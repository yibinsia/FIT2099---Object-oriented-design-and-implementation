package game.actors;


import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.AttackBehaviour;
import game.behaviours.WanderBehaviour;

/**
 * A class representing a Huntsman Spider, an Actor with specific behaviours in a game.
 * This spider can attack other actors and wander around the map.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by: Sheryl Lee, Shuntaro Yamada
 */
public class HuntsmanSpider extends Enemy {


    /**
     * Constructor. Initializes the Huntsman Spider with default behaviours.
     */
    public HuntsmanSpider() {
        super("Huntsman Spider", '8', 1);
        this.behaviours.put(999, new WanderBehaviour());
        this.behaviours.put(1, new AttackBehaviour());
    }

    /**
     * Defines the intrinsic weapon for the Huntsman Spider, which is used when it attacks.
     *
     * @return the intrinsic weapon with damage potential and attack verb
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        // 25% hit chance implemented in the weapon's effect
        return new IntrinsicWeapon(1, "swipes", 25);
    }
}