package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.abilities.Status;
import game.actions.AttackAction;

import java.util.Map;
import java.util.TreeMap;

/**
 * Abstract class representing an enemy in the game.
 * This class extends the Actor class.
 * An enemy can perform actions such as attacking other actors.
 * The actions that an enemy can perform are determined by the allowableActions method,
 * and its behaviours for each turn of play are defined in the playTurn method.
 * Created by:
 * @author Sheryl Lee
 * Modified by:
 * Sheryl Lee, Shuntaro Yamada
 */
public abstract class Enemy extends Actor {
    /**
     * Stores behaviors associated with specific conditions or priorities.
     */
    Map<Integer, Behaviour> behaviours = new TreeMap<>();

    /**
     * Constructor.
     *
     * @param name the name of the enemy
     * @param displayChar the character that will represent the enemy on the map
     * @param hitPoints the initial number of hit points of the enemy
     */
    public Enemy(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
    }

    /**
     * At each turn, the enemy will choose an action based on its predefined behaviours.
     * It will attack if possible, otherwise, it will wander or do nothing if no other actions are available.
     *
     * @param actions    collection of possible Actions for this Actor
     * @param lastAction the Action this Actor took last turn
     * @param map        the map containing the Actor
     * @param display    the I/O object to which messages may be written
     * @return the Action to be performed this turn
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * Determines the list of allowable actions for this enemy.
     * If the other actor is hostile to enemies, this method will add an attack action to the list of actions.
     * If the other actor has a weapon in their inventory, this method will add an attack action for each weapon to the list of actions.
     *
     * @param otherActor the Actor that is interacting with this hostile creature
     * @param direction the direction of the interaction
     * @param map the GameMap containing the Actor and this hostile creature
     * @return an ActionList of the actions this hostile creature can perform
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        IntrinsicWeapon weapon = otherActor.getIntrinsicWeapon();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            actions.add(new AttackAction(this, direction, weapon));
        }
        return actions;
    }
}