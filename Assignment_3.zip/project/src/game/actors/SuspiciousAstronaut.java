package game.actors;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.abilities.Status;
import game.actions.AttackAction;
import game.behaviours.AttackBehaviour;
import game.behaviours.FollowBehaviour;
import game.behaviours.WanderBehaviour;

import java.util.HashMap;
import java.util.Map;

/**
 * SuspiciousAstronaut is a type of Enemy in the game. It has the ability to attack other actors
 * and wander around the map. It has a very high hit point value and a powerful intrinsic weapon.
 * Created by:
 * @author Sheryl Lee
 * Modified by:
 * Sheryl Lee, Ting Guang Xun
 */
public class SuspiciousAstronaut extends Enemy {

    private static final int WANDER_BEHAVIOUR_PRIORITY = 999;
    private static final int ATTACK_BEHAVIOUR_PRIORITY = 1;
    private int damage = 0;


    /**
     * Constructor. Initializes the SuspiciousAstronaut with a name, the character 'ඞ',
     * and 99 hit points. It also adds the capabilities to attack other actors and wander.
     */
    public SuspiciousAstronaut() {
        super("Suspicious Astronaut", 'ඞ', 99);
        this.behaviours.put(ATTACK_BEHAVIOUR_PRIORITY, new AttackBehaviour());
        this.behaviours.put(WANDER_BEHAVIOUR_PRIORITY, new WanderBehaviour());
    }

    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        IntrinsicWeapon weapon = otherActor.getIntrinsicWeapon();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            damage = otherActor.getAttribute(BaseActorAttributes.HEALTH);
            actions.add(new AttackAction(this, direction, weapon));
        }
        return actions;
    }

    /**
     * Defines the intrinsic weapon for the SuspiciousAstronaut, which is used when it attacks.
     * The weapon has a very high damage potential and a 100% hit chance.
     *
     * @return the intrinsic weapon with damage potential and attack verb
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        // 100 hit chance implemented in the weapon's effect
        return new IntrinsicWeapon(damage, "kills", 100);
    }
}