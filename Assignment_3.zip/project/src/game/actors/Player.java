package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.displays.Menu;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.FancyMessage;
import game.abilities.Ability;
import game.abilities.Status;

/**
 * Class representing the Player in the game.
 * The player character has specific capabilities and actions it can perform each turn based on game conditions.
 * Created by: Adrian Kristanto
 * Modified by:
 * Shuntaro Yamada, Sia Yi Bin, Sheryl Lee
 */
public class Player extends Actor {
    private static final int INTRINSIC_DAMAGE = 1;   // The damage dealt by the player's intrinsic attack
    private static final String INTRINSIC_VERB = "punches";   // The verb to describe the player's intrinsic attack
    private static final int INTRINSIC_ACCURACY = 5;   // The accuracy percentage of the player's intrinsic attack

    /**
     * Constructor for the Player class.
     *
     * @param name        Name to call the player in the UI
     * @param displayChar Character to represent the player in the UI
     * @param hitPoints   Player's starting number of hitpoints
     */
    public Player(String name, char displayChar, int hitPoints) {
        super(name, displayChar, hitPoints);
        this.addCapability(Status.HOSTILE_TO_ENEMY);
        this.addCapability(Ability.ENTER_SPACESHIP);
        this.addCapability(Ability.EAT);
        this.addCapability(Ability.HAS_WALLET);
        this.addBalance(10000);
    }

    /**
     * Determines the player's action each turn, based on game status and previous actions.
     *
     * @param actions    Collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn, used to determine next actions
     * @param map        The map containing the Actor
     * @param display    The I/O object to which messages may be written
     * @return the Action to be performed this turn
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        if (lastAction != null && lastAction.getNextAction() != null) {
            return lastAction.getNextAction();
        }

        Menu menu = new Menu(actions);
        display.println("Intern HP: " + this.getAttribute(BaseActorAttributes.HEALTH)+"/"+this.getAttributeMaximum(BaseActorAttributes.HEALTH));
        display.println("Balance: " + this.getBalance());
        return menu.showMenu(this, display);
    }

    /**
     * This method is called when the player becomes unconscious (hit points fall to zero or below).
     * It removes the player from the game map and returns a message indicating the game over condition.
     *
     * @param actor Actor that caused the player to become unconscious, typically an enemy
     * @param map   The game map, which will have the player removed
     * @return A string message from FancyMessage indicating that the player has been fired (game over)
     */
    @Override
    public String unconscious(Actor actor, GameMap map) {
        map.removeActor(this);
        return FancyMessage.YOU_ARE_FIRED;  // Use the specific game over message from FancyMessage
    }

    /**
     * Returns the intrinsic weapon of the player. This weapon is used when no other weapons are available.
     *
     * @return the player's intrinsic weapon with predefined damage, verb, and accuracy
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon(){
        return new IntrinsicWeapon(INTRINSIC_DAMAGE, INTRINSIC_VERB, INTRINSIC_ACCURACY);
    }
}


