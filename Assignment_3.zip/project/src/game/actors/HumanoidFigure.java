package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.abilities.Ability;
import game.abilities.Status;
import game.actions.AttackAction;
import game.actions.SellAction;
import game.items.Sellable;

import java.util.List;

/**
 * HumanoidFigure is an actor having status ALLIES in the game.
 * It can let player sell items to it, and it cannot be attacked
 * by player.
 * Created by:
 * @author Sia Yi Bin
 * Modified by:
 * Sia Yi Bin
 */
public class HumanoidFigure extends Actor {

    /**
     * Constructor. Initializes the HumanoidFigure with display character 'H',
     * and 100 hit points. It also adds the capabilities to not attacked by player,
     * and can be sold items from player.
     */
    public HumanoidFigure() {
        super("Humanoid Figure", 'H', 100);
        this.addCapability(Status.ALLIES);
    }
    /**
     * Determines the HumanoidFigure's action each turn.
     * It will always perform DoNothingAction.
     *
     * @param actions    Collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn
     * @param map        The map containing the Actor
     * @param display    The I/O object to which messages may be written
     * @return the Action to be performed this turn
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {
        return new DoNothingAction();
    }

}
