package game.actors;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.DoNothingAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.Utility;
import game.abilities.Ability;
import game.abilities.Status;
import game.actions.AttackAction;
import game.behaviours.FollowBehaviour;
import game.behaviours.PickUpBehaviour;
import game.behaviours.WanderBehaviour;

import java.util.Map;
import java.util.TreeMap;

/**
 * AlienBug is a type of Enemy in the game. It has the ability to enter a spaceship,
 * pick up items, and wander around the map. It can also follow other actors
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun, Sheryl Lee
 */
public class AlienBug extends Enemy {

    /**
     * The actor that the AlienBug is currently following.
     */
    private Actor followTarget = null;
    private static final int WANDER_BEHAVIOUR_PRIORITY = 999;
    private static final int PICKUP_BEHAVIOUR_PRIORITY = 1;
    private static final int FOLLOW_BEHAVIOUR_PRIORITY = 2;

    /**
     * Constructor. Initializes the AlienBug with a randomly generated name, the character 'a',
     * and 2 hit points. It also adds the capabilities to enter a spaceship, pick up items, and wander.
     */
    public AlienBug() {
        super("Feature-" + Utility.generateRandomInt(3), 'a', 2);
        this.addCapability(Ability.ENTER_SPACESHIP);
        this.behaviours.put(PICKUP_BEHAVIOUR_PRIORITY, new PickUpBehaviour());
        this.behaviours.put(WANDER_BEHAVIOUR_PRIORITY, new WanderBehaviour());
    }

    /**
     * Determines the AlienBug's action each turn. It goes through its behaviours in order
     * and returns the first action that is not null. If all behaviours return null, it does nothing.
     *
     * @param actions    Collection of possible Actions for this Actor
     * @param lastAction The Action this Actor took last turn
     * @param map        The map containing the Actor
     * @param display    The I/O object to which messages may be written
     * @return the Action to be performed this turn
     */
    @Override
    public Action playTurn(ActionList actions, Action lastAction, GameMap map, Display display) {

        for (Behaviour behaviour : behaviours.values()) {
            Action action = behaviour.getAction(this, map);
            if(action != null)
                return action;
        }
        return new DoNothingAction();
    }

    /**
     * Returns a list of actions that other actors can perform on the AlienBug. If the other actor
     * is hostile to enemies, the AlienBug starts following them and the list includes an attack action.
     *
     * @param otherActor The Actor that might be performing action
     * @param direction  String representing the direction of the other Actor
     * @param map        GameMap containing the Actor and the other Actor
     * @return a collection of Actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, String direction, GameMap map) {
        ActionList actions = new ActionList();
        IntrinsicWeapon weapon = otherActor.getIntrinsicWeapon();
        if(otherActor.hasCapability(Status.HOSTILE_TO_ENEMY)){
            followTarget = otherActor;
            this.behaviours.put(FOLLOW_BEHAVIOUR_PRIORITY, new FollowBehaviour(otherActor));
            actions.add(new AttackAction(this, direction, weapon));
        }
        return actions;
    }

    /**
     * This method is called when the actor becomes unconscious (hit points fall to zero or below).
     * It removes the actor from the game map and returns a message indicating the game over condition.
     *
     * @param actor Actor that caused the player to become unconscious, typically an enemy
     * @param map   The game map, which will have the player removed
     * @return A string message that says it has been killed
     */
    @Override
    public String unconscious(Actor actor, GameMap map) {
        Location currentLocation = map.locationOf(this);
        for (Item item : this.getItemInventory()){
            currentLocation.addItem(item);
        }
        map.removeActor(this);

        return super.toString() + " has been killed!";
    }
}