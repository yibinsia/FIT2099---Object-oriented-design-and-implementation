package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.behaviours.GrowBehaviour;
/**
 * Represents a sprout tree in the game environment.
 * Sprouts are the initial stage of tree growth, and they transition to a sapling after a certain age.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamdada
 */
public class Sprout extends Inheritree{
    /**
     * Constructor for the Sprout class.
     * Initializes the sprout with a display character ','.
     */
    public Sprout(){
        super(',');
        addBehaviour(new GrowBehaviour(3, new SaplingTree()));
    }
    /**
     * Simulates the passage of time for the sprout tree.
     * This method handles the growth of the sprout and its transition to a sapling.
     *
     * @param location The current location of the sprout on the game map.
     */
    @Override
    public void tick(Location location){
        super.tick(location);
    }
}
