package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.behaviours.DropFruitBehaviour;
import game.behaviours.GrowBehaviour;
import game.spawners.SmallFruitSpawner;
import edu.monash.fit2099.engine.positions.Location;

import java.util.Random;

/**
 * Represents a sapling tree in the game environment.
 * Saplings are young trees that have the potential to grow into mature trees. They can occasionally drop small fruits
 * and will mature into a young inheritree after reaching a certain age.
 * Created by:
 * @author Shuntaro Yamdada
 * Modified by:
 * Shuntaro Yamdada
 */
public class SaplingTree extends Inheritree {
    /**
     * Constructor for the SaplingTree class.
     * Initializes the sapling with a display character 't'.
     */
    public SaplingTree(){
        super('t');
        addBehaviour(new GrowBehaviour(6, new YoungInheritree()));
        addBehaviour((new DropFruitBehaviour(new SmallFruitSpawner(), 0.3)));
    }
    /**
     * Simulates the passage of time for the sapling tree.
     * This method handles the growth of the sapling and its potential to spawn small fruits.
     *
     * @param location The current location of the sapling on the game map.
     */
    @Override
    public void tick(Location location){
        super.tick(location);
    }
}
