package game.grounds;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.ActorAttributeOperations;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ConsumeAction;
import game.abilities.Ability;
import game.items.Consumable;

/**
 * Represents a puddle on the ground within the game environment.
 * Puddles are not only passive ground elements characterized by a display character '~',
 * but also can be consumed by actors to potentially increase their health attributes.
 * Implements Consumable to allow actors with the appropriate ability to interact with puddles for health benefits.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * Sia Yi Bin
 */
public class Puddle extends Ground implements Consumable {

    /**
     * The amount of maximum health can be increased per drink.
     */
    private final int MAXIMUMHEALTH = 1;   // The maximum health that can be increased by consuming the puddle

    /**
     * Constructor for Puddle.
     * Initializes the puddle with a display character '~'.
     */
    public Puddle() {
        super('~');
    }
    /**
     * Gets the amount of health the puddle will provide when consumed.
     *
     * @return the maximum health benefit from consuming the puddle
     */
    public int getHealAmount(){return this.MAXIMUMHEALTH;}

    @Override
    public String getConsumableName() {
        return "puddle ";
    }

    /**
     * Provides a string to describe the menu action for consuming the puddle.
     *
     * @return a string that is used in the menu to represent the action of drinking water from the puddle
     */
    public String menustring(){
        return " drinks water from " + getConsumableName();
    }

    /**
     * Increase intern maximum health permanently by 1 after consumed
     * puddle one time.
     * @param owner The actor standing on the puddle
     * @return A string for description after consumed puddle
     */
    @Override
    public String consume(Actor owner){
        owner.modifyAttributeMaximum(BaseActorAttributes.HEALTH, ActorAttributeOperations.INCREASE,this.MAXIMUMHEALTH);
        return owner + " drinks " + getConsumableName() + " water and increased maximum health by " + this.MAXIMUMHEALTH;
    }
    /**
     * Provides a list of actions that can be performed on this puddle by actors,
     * specifically allowing actors with the capability to eat (or similar abilities) to consume the puddle.
     *
     * @param actor The actor inquiring about actions
     * @param location The location of the puddle
     * @param direction The direction from the actor to the puddle, used for action descriptions
     * @return an ActionList containing all allowable actions, particularly consumption
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction){
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT) && location.containsAnActor()) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}

