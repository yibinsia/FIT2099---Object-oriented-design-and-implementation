package game.grounds;
import edu.monash.fit2099.engine.positions.Location;

import java.util.Random;

import game.behaviours.DropFruitBehaviour;
import game.spawners.LargeFruitSpawner;
import game.spawners.Spawner;

/**
 * Represents a mature tree in the game environment.
 * Mature trees can drop large fruits at a specified probability each game tick.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamdada
 */
public class MatureTree extends Inheritree {
    /**
     * Constructor for the MatureTree class.
     * Initializes the mature tree with a display character 'T'.
     */
    public MatureTree(){
        super('T');
        addBehaviour(new DropFruitBehaviour(new LargeFruitSpawner(), 0.2));
    }
    /**
     * Simulates the passage of time for the mature tree.
     * This method handles the potential to spawn large fruits.
     *
     * @param location The current location of the mature tree on the game map.
     */
    @Override
    public void tick(Location location){
        super.tick(location);
    }
}

