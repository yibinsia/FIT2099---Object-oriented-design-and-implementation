package game.grounds;

import game.behaviours.GrowBehaviour;
import edu.monash.fit2099.engine.positions.Location;
/**
 * Represents a young inheritree in the game environment.
 * Young inheritrees are an intermediate stage of tree growth and will mature after a certain age.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamdada
 */
public class YoungInheritree extends Inheritree{
    /**
     * Constructor for the YoungInheritree class.
     * Initializes the young inheritree with a display character 'y'.
     */
    public YoungInheritree(){
        super('y');
        addBehaviour(new GrowBehaviour(5, new MatureTree()));
    }
    /**
     * Simulates the passage of time for the young inheritree.
     * This method handles the growth of the young inheritree.
     *
     * @param location The current location of the young inheritree on the game map.
     */
    @Override
    public void tick(Location location){
        super.tick(location);
    }
}
