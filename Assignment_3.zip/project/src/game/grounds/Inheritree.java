package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.behaviours.PlantBehaviour;
import java.util.List;
import java.util.ArrayList;

/**
 * Abstract base class representing a tree-like structure in the game environment.
 * This class includes basic properties common to tree-like entities, such as age,
 * and requires implementing classes to define specific behaviors that occur over time.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public abstract class Inheritree extends Ground {
    /**
     * The age of the tree.
     */
    protected  int age = 0;
    /**
     * List of behaviors associated with this tree.
     */
    protected List<PlantBehaviour> behaviours = new ArrayList<>();
    /**
     * Constructor for Inheritree.
     * Initializes the tree-like entity with a specific display character.
     *
     * @param displayChar The character to display this entity on the map.
     */
    public Inheritree(char displayChar) {
        super(displayChar);
    }
    /**
     * Simulates a single time unit passage for this tree.
     * This method increments the age and executes all associated behaviors.
     *
     * @param location The current location of the tree on the game map.
     */
    @Override
    public void tick(Location location) {
        age++;
        for (PlantBehaviour behaviour : behaviours) {
            behaviour.execute(this, location);
        }
    }
    /**
     * Adds a new behavior to this tree.
     *
     * @param behaviour The behavior to add.
     */
    public void addBehaviour(PlantBehaviour behaviour) {
        behaviours.add(behaviour);
    }
    /**
     * Gets the age of this tree.
     *
     * @return The age of the tree.
     */
    public int getAge() {
        return age;
    }
}



