package game.grounds;

import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.ActionList;
import game.actions.PurchaseAction;
import game.items.Purchasable;
import edu.monash.fit2099.engine.displays.Display;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * The ComputerTerminal class represents a computer terminal in the game environment.
 * A ComputerTerminal provides two main functionalities:
 * 1. It allows actors to purchase items from a list of purchasable items.
 * 2. It allows actors to travel to different game maps.
 *
 * The ComputerTerminal class extends the Ground class, meaning it can be placed on the game map.
 *
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada, Sheryl Lee
 */
public class ComputerTerminal extends Ground {
    /**
     * A list of items that can be purchased from this ComputerTerminal.
     */
    private List<Purchasable> purchasableItems;
    /**
     * A map of the available locations that can be traveled to from this ComputerTerminal.
     * The map's keys are the GameMap objects representing the locations, and the values are HashMaps containing the name of the location and the terminal's location within that map.
     */
    private HashMap<GameMap, HashMap<String, Object>> locations;

    /**
     * Constructor for the ComputerTerminal class.
     * Initializes the ComputerTerminal with a list of purchasable items and a map of available locations.
     *
     * @param purchasableItems a list of items that can be purchased from this ComputerTerminal
     * @param locations a map of the available locations that can be traveled to from this ComputerTerminal
     */
    public ComputerTerminal(List<Purchasable> purchasableItems, HashMap<GameMap, HashMap<String, Object>> locations) {
        super('=');
        this.purchasableItems = purchasableItems;
        this.locations = locations;
    }

    /**
     * Returns a list of actions that can be performed by the given actor at this ComputerTerminal.
     * The actions include purchasing items from the ComputerTerminal and traveling to different game maps.
     *
     * @param actor the actor for which to return the allowable actions
     * @param location the location of the ComputerTerminal
     * @param direction the direction of the ComputerTerminal from the actor
     * @return a list of actions that can be performed by the actor at this ComputerTerminal
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        GameMap currentMap = location.map();
        ActionList actions = new ActionList();

        for (Purchasable item : purchasableItems) {
            actions.add(new PurchaseAction(item));
        }

        Set<Map.Entry<GameMap, HashMap<String, Object>>> entrySet = locations.entrySet();
        for (Map.Entry<GameMap, HashMap<String, Object>> entry : entrySet) {
            if (entry.getKey() != currentMap) {
                Location terminalLocation = (Location) entry.getValue().get("terminalLocation");

                actions.add(new MoveActorAction(terminalLocation, "to " + entry.getValue().get("name")) {
                    @Override
                    public String menuDescription(Actor actor) {
                        return "Travel to " + entry.getValue().get("name");
                    }
                    @Override
                    public String execute(Actor actor, GameMap map) {
                        if (terminalLocation.containsAnActor()) {
                            // Display error message if terminal location is occupied by an actor
                            return ("Cannot travel to " + entry.getValue().get("name") + " as another actor is on the terminal.");
                        } else {
                            map.moveActor(actor, terminalLocation);
                            return (actor + " arrived at " + terminalLocation + " in " + entry.getValue().get("name"));
                        }
                    }
                });
            }
        }
        return actions;
    }
}