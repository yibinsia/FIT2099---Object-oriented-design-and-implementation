package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;

/**
 * Represents a wall, an impassable barrier in the game environment.
 */
public class Wall extends Ground {

    /**
     * Constructor for Wall.
     * Initializes the wall with a display character '#'.
     */
    public Wall() {
        super('#');
    }

    /**
     * Determines if an actor can enter this ground spot.
     * Walls are impassable, so this always returns false.
     *
     * @param actor the actor attempting to enter this location
     * @return false, indicating no actor can pass through
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
