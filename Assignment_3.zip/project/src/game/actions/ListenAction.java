package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.items.Listenable;

/**
 * Class representing a listen action in a game.
 * This action allows an actor to listen to a Listenable item.
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun
 */
public class ListenAction extends Action {

    /**
     * The item that is to be listened
     */
    private Listenable listenable;

    /**
     * Constructor for specifying a weapon in addition to the target and direction.
     *
     * @param listenable    the item that is to be listened
     */
    public ListenAction(Listenable listenable){
        this.listenable = listenable;
    }

    /**
     * Execute the listen action.
     *
     * @param actor the actor performing the listen
     * @param map   the game map, used to apply the results of the listen
     * @return a string describing the outcome of the listen
     */
    @Override
    public String execute(Actor actor, GameMap map){
        return listenable.monologueOption(actor);
    }

    /**
     * Provides a description of the action for the menu.
     *
     * @param actor the actor performing the listen action
     * @return a string describing the action for display in menus
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " listens to " + listenable.getName();
    }


}
