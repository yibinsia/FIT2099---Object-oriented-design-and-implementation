package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.items.Sellable;

/**
 * Class representing a sell action in a game.
 * This action allows an actor to sell an item and earn credit.
 * Created by:
 * @author Sia Yi Bin
 * Modified by:
 * Sia Yi Bin
 */
public class SellAction extends Action {
    /**
     * The item that is to be purchased
     */
    private Sellable item;

    /**
     * Constructor for specifying a purchasableItem
     *
     * @param item    the item that is to be purchased
     */
    public SellAction(Sellable item){
        this.item = item;
    }

    public Sellable getItem() {
        return item;
    }

    /**
     * Execute the purchase action.
     *
     * @param actor the actor performing the purchase
     * @param map   the game map, used to apply the results of the purchase
     * @return a string describing the outcome of the purchase
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return item.sell(actor, map);
    }


    /**
     * Provides a description of the action for the menu.
     *
     * @param actor the actor performing the purchase action
     * @return a string describing the action for display in menus
     */
    @Override
    public String menuDescription(Actor actor) {
        return "Sells " + item.getName();
    }
}
