package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actions.MoveActorAction;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.NumberRange;

import java.util.Random;

/**
 * The Theseus class represents a special item in the game that allows the player to teleport to a random location.
 * Theseus is a purchasable item, and once purchased, it can be used to perform a teleportation action.
 * The teleportation action moves the player to a random location on the current map that does not contain another actor.
 *
 * Theseus extends the Item class and implements the Purchasable interface.
 *
 * Created by:
 * @author Sheryl Lee
 * Modified by:
 * Sheryl Lee
 */
public class Theseus extends Item implements Purchasable {
    /**
     * The cost to purchase Theseus.
     */
    private static final int COST = 100;

    /**
     * Constructor for the Theseus class.
     * Initializes Theseus with a name, display character, and sets it as portable.
     */
    public Theseus() {
        super("THESEUS", '^', true);
    }

    /**
     * Returns the cost to purchase Theseus.
     *
     * @return the cost of Theseus
     */
    @Override
    public int getCost() {
        return COST;
    }

    /**
     * Returns the name of Theseus.
     *
     * @return the name of Theseus
     */
    @Override
    public String getName() {
        return "THESEUS";
    }

    /**
     * Attempts to purchase Theseus.
     * If the actor has enough balance, deducts the cost from the actor's balance, adds Theseus to the actor's inventory,
     * and returns a success message. If the actor does not have enough balance, returns a failure message.
     *
     * @param actor the actor attempting to purchase Theseus
     * @return a string message indicating the result of the purchase attempt
     */
    @Override
    public String purchase(Actor actor) {
        if (actor.getBalance() >= COST) {
            actor.deductBalance(COST);
            actor.addItemToInventory(this);
            return actor + " successfully purchased a " + getName() + " for " + COST + " credits.";
        } else {
            return "Not enough credits to purchase a " + getName() + ".";
        }
    }

    /**
     * Returns a list of actions that can be performed with Theseus.
     * In this case, the only action is a teleportation action that moves the actor to a random location on the current map.
     *
     * @param location the location of Theseus
     * @return a list of actions that can be performed with Theseus
     */
    @Override
    public ActionList allowableActions(Location location) {

        // Get new random location on same map
        Random random = new Random();
        GameMap currentMap = location.map();
        NumberRange xRange = currentMap.getXRange();
        NumberRange yRange = currentMap.getYRange();
        int x, y;
        Location destination;

        do {
            x = random.nextInt(xRange.max()) + xRange.min();
            y = random.nextInt(yRange.max()) + yRange.min();
            destination = currentMap.at(x, y);
        } while (destination.containsAnActor());

        // return new travel location
        ActionList actions = new ActionList();
        Location finalDestination = destination;
        actions.add(new MoveActorAction(finalDestination, "Teleportation") {
            @Override
            public String menuDescription(Actor actor){
                return "Teleport with THESEUS";
            }

            @Override
            public String execute(Actor actor, GameMap map){
                map.moveActor(actor, finalDestination);
                return (actor + " teleported to " + finalDestination);
            }
        });
        return actions;
    }
}


