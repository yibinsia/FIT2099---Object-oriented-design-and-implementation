package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.ListenAction;

import java.util.ArrayList;
import java.util.Random;
/**
 * Astley can be purchased by actors from ComputerTerminal and the monologues can be listened by actors when it is in subsciption
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun
 */
public class Astley extends Item implements Purchasable, Listenable{
    /**
     * Cost of Astley in game credits
     */
    private static final int COST = 50;
    private static final String NAME = "Astley";
    private static final char DISPLAYCHAR= 'z';
    /**
     * A boolean value indicating that whether Astley is in subscription or not
     */
    private boolean inSubscription = true;
    /**
     * A counter to keep track of the number of turns passed
     */
    private int counter = 0;



    /**
     * Constructor for Astley
     * Initializes Astley with a name, display character output and a portable boolean value
     */
    public Astley(){
        super(NAME, DISPLAYCHAR, true);
    }

    /**
     * A function that randomly chooses which monologue to be returned.
     * Monologue options are created by creating an instance of Monologue, passing the boolean value and monologue String as an argument into it
     */
    public String monologueOption(Actor actor){
        Random random = new Random();
        ArrayList<String> options = new ArrayList<String>();
        String retString = null;
        options.add(new Monologue(true, "The factory will never gonna give you up, valuable intern!").getMonologue());
        options.add(new Monologue(true, "We promise we never gonna let you down with a range of staff benefits.").getMonologue());
        options.add(new Monologue(true, "We never gonna run around and desert you, dear intern!").getMonologue());
        options.add(new Monologue(actor.getItemInventory().size()>10, "We never gonna make you cry with unfair compensation.").getMonologue());
        options.add(new Monologue(actor.getBalance() > 50, "Trust is essential in this business. We promise we never gonna say goodbye to a valuable intern like you.").getMonologue());
        options.add(new Monologue(actor.getAttribute(BaseActorAttributes.HEALTH)<2, "Don't worry, we never gonna tell a lie and hurt you, unlike those hostile creatures.").getMonologue());

        while(retString == null){
            int randomIndex = random.nextInt(options.size());
            retString = options.get(randomIndex);
        }

        return retString;
    };

    /**
     * Inform a carried Item of the passage of time.
     * This function handles the subscription logic of Astley, a subscription fee should be paid every 5 turns
     * This method is called once per turn, if the Item is being carried.
     * @param currentLocation The location of the actor carrying this Item.
     * @param actor The actor carrying this Item.
     */
    @Override
    public void tick(Location currentLocation, Actor actor) {
        if (counter != 0 && counter % 5 == 0) {
            if (actor.getBalance() > 0) {
                actor.deductBalance(1);
                Display disp = new Display();
                disp.println("Subscription payment for Astley has been received!");
                this.inSubscription = true;
            } else {
                this.inSubscription = false;
            }
        }
        counter++;
    }

    /**
     * Returns a list of actions that can be performed with Astley.
     * In this case, the only action is a listen action that allows the actor to listen to the monologue
     * @param owner the actor carrying Astley
     * @return a list of actions that can be performed with Astley
     */
    @Override
    public ActionList allowableActions(Actor owner){
        ActionList actions = new ActionList();
        if (this.inSubscription) {
            actions.add(new ListenAction(this));
        }
        return actions;
    }

    /**
     * Allows an actor to purchase Astley if they have sufficient credits.
     * @param actor The actor attempting to purchase the sword
     * @return A string message indicating the success or failure of the purchase
     */
    @Override
    public String purchase(Actor actor){
        if (actor.getBalance() >= COST){
            actor.deductBalance(COST);
            actor.addItemToInventory(this);
            return actor + " successfully purchased an " + getName() +" for " + COST + " credits.";
        }
        else{
            return "Not enough credits to purchase an "+ getName() +".";
        }
    }

    /**
     * Gets the cost of purchasing the Astley.
     *
     * @return The cost in credits
     */
    @Override
    public int getCost(){
        return COST;
    }

    /**
     * Gets the name of the Astley.
     *
     * @return The name of the Astley.
     */
    @Override
    public String getName(){
        return NAME;
    }
}
