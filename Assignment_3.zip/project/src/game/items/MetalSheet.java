package game.items;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.abilities.Status;
import game.actions.SellAction;

/**
 * Represents a metal sheet, typically used as a crafting component or defensive gear within the game.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin
 */
public class MetalSheet extends Item implements Sellable{
    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 20;


    /**
     * Constructor for the MetalSheet.
     * Initializes the MetalSheet with its name, display character, and portability.
     */
    public MetalSheet() {
        super("Metal Sheet", '%', true);
    }

    /**
     * Sells the item and updates the actor's balance.
     *
     * This method allows an actor to sell the item (MetalSheet) for its value.
     * The value is added to the actor's balance, and the item is removed from the actor's inventory.
     *
     * @param actor The actor selling the item.
     * @param map The game map where the action is taking place.
     * @return A string describing the result of the sell action.
     */
    @Override
    public String sell(Actor actor, GameMap map) {
        int value = getValue();
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the item.
     * There is 60% chance that the value will be halved.
     * @return The value of the item.
     */
    @Override
    public int getValue() {
        if (Math.random() <= 0.6){
            return VALUE/2;
        }
        return VALUE;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    @Override
    public String getName() {
        return "Metal Sheet";
    }

    /**
     * Returns the allowable actions that can be performed by an actor
     * possessing the MetalSheet.
     * This method determines the actions that an actor can perform when
     * they have a MetalSheet. Specifically, if the actor has the
     * capability of being an ally (indicated by the `Status.ALLIES` capability),
     * they are allowed to perform a `SellAction` involving MetalSheet.
     *
     * @param otherActor The actor possessing the MetalSheet and for whom the actions are being determined.
     * @param location The current location of the actor.
     * @return An `ActionList` containing the actions that the actor can perform with MetalSheet.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.ALLIES)){
            actions.add(new SellAction(this));
        }
        return actions;
    }
}
