package game.items;


/**
 * Class representing a monologue option for Listenable Item.
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun
 */
public class Monologue {
    /**
     * A boolean value indicating that whether the monologue option is available or not
     */
    private boolean condition;
    /**
     * A string value of the monologue option
     */
    private String option;


    /**
     * Constructor for Monologue
     * Initializes Monologue with a boolean value and a String value of monologue options
     */
    public Monologue(Boolean bool, String option){
        this.condition = bool;
        this.option = option;
    }

    /**
     * Retrieves the monologue option if the condition is true
     *
     * @return the monologue option
     */
    public String getMonologue(){
        if(this.condition == true){
            return option;
        }
        return null;
    }
}
