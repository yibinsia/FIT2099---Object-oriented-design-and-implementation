package game.items;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * Interface representing items that can be listened by actors.
 * Created by:
 * @author Ting Guang Xun
 * Modified by:
 * Ting Guang Xun
 */
public interface Listenable {

    /**
     * Contains an ArrayList<String> which stores the available monologue options, randomly returns 1 available monologue option
     *
     * @param actor The actor listening to the item.
     */
    String monologueOption(Actor actor);

    /**
     * Retrieves the name of the item.
     *
     * @return the name of item
     */
    String getName();
}
