package game.items;

import edu.monash.fit2099.engine.actors.Actor;


/**
 * Interface representing items that can be purchased by actors.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public interface Purchasable {

    /**
     * Purchases the item, adding the item to inventory of actor.
     *
     * @param actor The actor purchasing the item.
     */
    String purchase(Actor actor);

    /**
     * Retrieves the cost of the item.
     *
     * @return the cost of item
     */
    int getCost();

    /**
     * Retrieves the name of the item.
     *
     * @return the name of item
     */
    String getName();
}
