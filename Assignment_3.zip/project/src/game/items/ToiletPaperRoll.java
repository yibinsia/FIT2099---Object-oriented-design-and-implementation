package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actors.attributes.BaseActorAttributes;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.abilities.Status;
import game.actions.SellAction;

/**
 * ToiletPaperRoll is a class that represents a purchasable item in the game.
 * This class extends the Item abstract class and implements the Purchasable interface.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada, Sia Yi Bin
 */
public class ToiletPaperRoll extends Item implements Purchasable, Sellable{

    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 1;
    /**
     * The normal cost of the ToiletPaperRoll.
     */
    private static final int NORMAL_COST = 5;
    /**
     * The discounted cost of the ToiletPaperRoll.
     */
    private static final int DISCOUNTED_COST = 1;


    /**
     * Constructor for the ToiletPaperRoll class.
     * Initializes the item with the name "Toilet Paper Roll", the character 's', and sets it as portable.
     */
    public ToiletPaperRoll(){
        super("Toilet Paper Roll", 's', true);
    }

    /**
     * Executes the purchase of the ToiletPaperRoll by an actor.
     * If the actor has enough balance, the cost of the ToiletPaperRoll is deducted from the actor's balance,
     * and the ToiletPaperRoll is added to the actor's inventory.
     * @param actor The actor that attempts to purchase the ToiletPaperRoll.
     * @return A string that represents the result of the purchase attempt.
     */
    @Override
    public String purchase(Actor actor){
        int cost = getCost();
        if (actor.getBalance() >= cost){
            actor.deductBalance(cost);
            actor.addItemToInventory(this);
            return actor + " successfully purchased a " +getName()+" for " + cost + " credits.";
        }
        else{
            return "Not enough credits to purchase a "+getName()+".";
        }
    }

    /**
     * Returns the cost of the ToiletPaperRoll.
     * There is a 75% chance that the cost will be the discounted cost, otherwise it will be the normal cost.
     * @return The cost of the ToiletPaperRoll.
     */
    @Override
    public int getCost(){
        if (Math.random() <= 0.75){
            return DISCOUNTED_COST;
        }
        return NORMAL_COST;
    }

    /**
     * Executes the sell action for the ToiletPaperRoll by an actor.
     * If the actor try to sell ToiletPaperRoll to Humanoid Figure and don't get killed,
     * the ToiletPaperRoll will be removed from the actor's inventory,
     * Otherwise, game over, actor is instantly get killed.
     * @param actor The actor that attempts to sell the ToiletPaperRoll.
     * @param map The
     * @return A string that represents the result of the sell attempt.
     */
    @Override
    public String sell(Actor actor, GameMap map) {

        int value = getValue();

        // Intern-specific logic: 50% chance of being killed instantly
        if (Math.random() <= 0.5) {
            actor.hurt(actor.getAttribute(BaseActorAttributes.HEALTH));
            Display display = new Display();
            display.println(actor + " attempted to sell a " + getName() + ", but was killed instantly by the humanoid figure!");
            return actor.unconscious(actor, map);
        }

        // Proceed with normal selling logic
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the ToiletPaperRoll.
     * @return The value of the ToiletPaperRoll.
     */
    @Override
    public int getValue() {
        return VALUE;
    }

    /**
     * Returns the name of the ToiletPaperRoll.
     * @return The name of the ToiletPaperRoll.
     */
    @Override
    public String getName() {
        return "Toilet Paper Roll";
    }

    /**
     * Returns the allowable actions that can be performed by an actor
     * possessing the ToiletPaperRoll.
     * This method determines the actions that an actor can perform when
     * they have a ToiletPaperRoll. Specifically, if the actor has the
     * capability of being an ally (indicated by the `Status.ALLIES` capability),
     * they are allowed to perform a `SellAction` involving the ToiletPaperRoll.
     *
     * @param otherActor the actor possessing the ToiletPaperRoll and for whom the actions are being determined.
     * @param location the current location of the actor.
     * @return an `ActionList` containing the actions that the actor can perform with the ToiletPaperRoll.
     */
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.ALLIES)){
            actions.add(new SellAction(this));
        }
        return actions;
    }

}
