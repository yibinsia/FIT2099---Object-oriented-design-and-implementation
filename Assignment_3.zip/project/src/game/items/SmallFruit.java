package game.items;
import edu.monash.fit2099.engine.items.Item;
import game.abilities.Ability;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import game.actions.ConsumeAction;

/**
 * SmallFruit is a class that represents a consumable item in the game.
 * It provides health benefits when consumed by an actor.
 * This class extends the Item abstract class and implements the Consumable interface.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin
 */
public class SmallFruit extends Item implements Consumable{
    /**
     * The amount of hit points that this item can heal.
     */
    public final int HEALPOINTS = 2;


    /**
     * Constructor for the SmallFruit class.
     * Initializes the item with the name "Small Fruit", the character 'o', and sets it as portable.
     */
    public SmallFruit(){
        super("Small Fruit", 'o', true);
    }

    /**
     * Returns the amount of hit points that this item can heal.
     * @return The healing amount of this item.
     */
    public int getHealAmount(){return this.HEALPOINTS;}

    /**
     * Returns the name of the consumable item.
     * @return The name of the consumable item.
     */
    public String getConsumableName(){return this.toString();}

    /**
     * Returns a string that represents the actor consuming the item.
     * @return A string that represents the actor consuming the item.
     */
    public String menustring(){
        return " consumes " + getConsumableName();
    }

    /**
     * Heals the actor based on each specific healing effect and remove the consumed item from actor's inventory
     */
    @Override
    public String consume(Actor owner){
        owner.heal(this.HEALPOINTS);
        owner.removeItemFromInventory(this);
        return owner + " consumes " + getConsumableName() + " and gains " + HEALPOINTS + " HP.";
    }

    /**
     * Returns a list of actions that the actor can perform with this item.
     * If the actor has the ability to eat, a ConsumeAction is added to the list.
     * @param actor The actor that can potentially perform actions with this item.
     * @return A list of actions that the actor can perform with this item.
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}