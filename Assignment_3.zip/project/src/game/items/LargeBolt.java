package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.abilities.Status;
import game.actions.SellAction;


/**
 * Represents a large bolt, typically used as a crafting component or trade item within the game.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin
 */
public class LargeBolt extends Item implements Sellable{
    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 25;


    /**
     * Constructor for the LargeBolt.
     * Initializes the LargeBolt with its name, display character, and portability.
     */
    public LargeBolt(){
        super ("Large Bolt", '+', true);
    }

    /**
     * Sells the item and updates the actor's balance.
     *
     * This method allows an actor to sell the item (LargeBolt) for its value.
     * The value is added to the actor's balance, and the item is removed from the actor's inventory.
     *
     * @param actor The actor selling the item.
     * @param map The game map where the action is taking place.
     * @return A string describing the result of the sell action.
     */
    @Override
    public String sell(Actor actor, GameMap map) {
        int value = getValue();
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the item.
     * @return The value of the item.
     */
    @Override
    public int getValue() {
        return VALUE;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    @Override
    public String getName() {
        return "Large Bolt";
    }

    /**
     * Returns the allowable actions that can be performed by an actor
     * possessing the LargeBolt.
     * This method determines the actions that an actor can perform when
     * they have a LargeBolt. Specifically, if the actor has the
     * capability of being an ally (indicated by the `Status.ALLIES` capability),
     * they are allowed to perform a `SellAction` involving LargeBolt.
     *
     * @param otherActor The actor possessing the LargeBolt and for whom the actions are being determined.
     * @param location The current location of the actor.
     * @return An `ActionList` containing the actions that the actor can perform with LargeBolt.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.ALLIES)){
            actions.add(new SellAction(this));
        }
        return actions;
    }
}
