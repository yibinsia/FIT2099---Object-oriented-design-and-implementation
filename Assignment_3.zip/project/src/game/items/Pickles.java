package game.items;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.abilities.Ability;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import game.abilities.Status;
import game.actions.ConsumeAction;
import game.actions.SellAction;

import java.util.Random;

/**
 * Class representing a Pickles item, able to be picked up by intern
 * able to be consumed by intern for increase hit points by 1 or
 * decrease hit points by 1.
 * Created by:
 * @author Sia Yi Bin
 * Modified by:
 * Sia Yi Bin
 */
public class Pickles extends Item implements Consumable, Sellable{
    /**
     * The amount of hit points can be increased or decreased per consume.
     */
    private final int HEALPOINTS = 1;
    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 25;


    /**
     * Constructor for Pickles.
     * Initializes the pickles with a display character 'n'.
     */
    public Pickles() {super("a jar of pickles", 'n', true);}

    /**
     * Randomly decide the heal amount is 1 or -1.
     * @return An integer representing the heal or hurt amount
     */
    public int getHealAmount() {
        Random random = new Random();
        boolean isExpired = random.nextBoolean(); // 50% chance of being expired
        if (isExpired) {
            // If it's past its expiry date, the Intern will be hurt by 1 point
            return (-HEALPOINTS);
        } else {
            // Otherwise, the Intern will be healed by 1 point
            return HEALPOINTS;
        }
    }

    /**
     * Getter of the class name.
     * @return The name of this class.
     */
    public String getConsumableName(){return this.toString();}

    /**
     * Getter of the menu description of this class
     * @return The menu description of this class.
     */
    public String menustring(){
        return " consumes " + getConsumableName();
    }

    /**
     * Heal the intern if the pickles hasn't expired, hurt the intern
     * if the pickles has expired.
     * @param owner The actor carrying pickles
     * @return A string for description after consumed pickles
     */
    @Override
    public String consume(Actor owner) {
        int healAmount = getHealAmount();
        owner.removeItemFromInventory(this);
        if (healAmount > 0) {
            // If the pickles are not expired, heal the owner
            owner.heal(healAmount);
            return owner + " consumes " + getConsumableName() + " and gains " + healAmount + " HP.";
        } else {
            // If the pickles are expired, hurt the owner
            owner.hurt(Math.abs(healAmount));
            return owner + " consumes " + getConsumableName() + " and loses " + Math.abs(healAmount) + " HP.";
        }
    }

    /**
     * Sells the item and updates the actor's balance.
     *
     * This method allows an actor to sell the item (a jar of pickles) for its value.
     * The value is added to the actor's balance, and the item is removed from the actor's inventory.
     *
     * @param actor The actor selling the item.
     * @param map The game map where the action is taking place.
     * @return A string describing the result of the sell action.
     */
    @Override
    public String sell(Actor actor, GameMap map) {
        int value = getValue();
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the item.
     * There is a 50% chance that the value is doubled.
     * @return The value of the item.
     */
    @Override
    public int getValue() {
        if (Math.random() <= 0.5) {
            return VALUE * 2;
        }
        return VALUE;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    @Override
    public String getName() {
        return "a jar of pickles";
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }

        return actions;
    }

    /**
     * Returns the allowable actions that can be performed by an actor
     * possessing the jar of pickles.
     * This method determines the actions that an actor can perform when
     * they have a jar of pickles. Specifically, if the actor has the
     * capability of being an ally (indicated by the `Status.ALLIES` capability),
     * they are allowed to perform a `SellAction` involving the jar of pickles.
     *
     * @param otherActor The actor possessing the jar of pickles and for whom the actions are being determined.
     * @param location The current location of the actor.
     * @return An `ActionList` containing the actions that the actor can perform with the jar of pickles.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.ALLIES)) {
            actions.add(new SellAction(this));
        }
        return actions;
    }
}

