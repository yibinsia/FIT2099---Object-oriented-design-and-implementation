package game.items;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import game.abilities.Ability;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import game.abilities.Status;
import game.actions.ConsumeAction;
import edu.monash.fit2099.engine.items.Item;
import game.actions.SellAction;


/**
 * A class that represents an Item with healing effect
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin
 */
public class LargeFruit extends Item implements Consumable, Sellable {
    /**
     * The amount of hit points that this item can heal
     */
    public final int HEALPOINTS = 2;
    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 30;


    /**
     * Constructor for LargeFruit.
     * Initializes the large fruit with a display character '0'.
     */
    public LargeFruit(){
        super("Big Fruit", '0', true);
    }

    /**
     * Retrieves the amount of health the item restores when consumed.
     *
     * @return the healing amount
     */
    public int getHealAmount(){
        return this.HEALPOINTS;
    }

    /**
     * Gets the name of the consumable item.
     *
     * @return the name of the consumable
     */
    public String getConsumableName(){
        return this.toString();
    }

    /**
     * Gets the string to be display on the menu of the consumable item.
     *
     * @return the string to be display on the menu
     */
    public String menustring(){
        return " consumes " + getConsumableName();
    }

    /**
     * Heal the intern by 2 hit points after consumed large fruit
     * @param owner The actor carrying large fruit
     * @return A string for description after consumed large fruit
     */
    @Override
    public String consume(Actor owner){
        owner.heal(this.HEALPOINTS);
        owner.removeItemFromInventory(this);
        return owner + " consumes " + getConsumableName() + " and gains " + HEALPOINTS + " HP.";
    }

    /**
     * Sells the item and updates the actor's balance.
     *
     * This method allows an actor to sell the item (LargeFruit) for its value.
     * The value is added to the actor's balance, and the item is removed from the actor's inventory.
     *
     * @param actor The actor selling the item.
     * @param map The game map where the action is taking place.
     * @return A string describing the result of the sell action.
     */
    @Override
    public String sell(Actor actor, GameMap map) {
        int value = getValue();
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the item.
     * @return The value of the item.
     */
    @Override
    public int getValue() {
        return VALUE;
    }
    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    @Override
    public String getName() {
        return "Large Fruit";
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }

    /**
     * Returns the allowable actions that can be performed by an actor
     * possessing the LargeFruit.
     * This method determines the actions that an actor can perform when
     * they have a LargeFruit. Specifically, if the actor has the
     * capability of being an ally (indicated by the `Status.ALLIES` capability),
     * they are allowed to perform a `SellAction` involving LargeFruit.
     *
     * @param otherActor The actor possessing the LargeFruit and for whom the actions are being determined.
     * @param location The current location of the actor.
     * @return An `ActionList` containing the actions that the actor can perform with LargeFruit.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = new ActionList();
        if (otherActor.hasCapability(Status.ALLIES)){
            actions.add(new SellAction(this));
        }
        return actions;
    }
}
