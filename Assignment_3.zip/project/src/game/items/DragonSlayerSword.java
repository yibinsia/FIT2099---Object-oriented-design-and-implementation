package game.items;

import edu.monash.fit2099.engine.weapons.WeaponItem;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;

/**
 * Represents the Dragon Slayer Sword, a powerful weapon in the game.
 * This sword can be purchased and used by actors to perform high-damage attacks. It also has a significant hit rate,
 * making it a formidable tool in combat against dragons or other formidable enemies.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public class DragonSlayerSword extends WeaponItem implements Purchasable{
    /**
     * The cost of purchasing the Dragon Slayer Sword.
     */
    private static final int COST = 100;
    /**
     * The damage dealt by the Dragon Slayer Sword.
     */
    private static final int DAMAGE = 50;
    /**
     * The hit rate of the Dragon Slayer Sword.
     */
    private static final int HIT_RATE = 75;

    /**
     * Constructor for the Dragon Slayer Sword.
     * Initializes the sword with a name, display character, damage output, attack verb, and hit rate.
     */
    public DragonSlayerSword(){
        super("Dragon Slayer Sword", 'x',  DAMAGE, "slashes", HIT_RATE);
    }

    /**
     * Allows an actor to purchase the Dragon Slayer Sword if they have sufficient credits.
     * The purchase can randomly fail due to printing errors, simulating a transaction issue.
     *
     * @param actor The actor attempting to purchase the sword
     * @return A string message indicating the success or failure of the purchase
     */
    @Override
    public String purchase(Actor actor) {
        if (actor.getBalance() >= COST) {
            if (Math.random() <= 0.5) {
                actor.deductBalance(COST);
                return COST + " credits taken but failed to print the "+getName()+".";
            } else {
                actor.deductBalance(COST);
                actor.addItemToInventory(this);
                return actor + " successfully purchased a "+ getName() +" for " + COST + " credits.";
            }
        } else {
            return "Not enough credits to purchase a " +getName()+".";
        }
    }

    /**
     * Provides a list of actions that can be performed with the Dragon Slayer Sword at a given location.
     * This includes attacking other actors in the vicinity.
     *
     * @param otherActor The actor against whom the sword might be used
     * @param location   The location where the action would take place
     * @return An ActionList containing all allowable actions, including attack actions
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location){
        ActionList actions = super.allowableActions((location));
        actions.add(new AttackAction(otherActor, location.toString(),this));
        return actions;
    }

    /**
     * Gets the cost of purchasing the Dragon Slayer Sword.
     *
     * @return The cost in credits
     */
    @Override
    public int getCost(){
        return COST;
    }

    /**
     * Gets the name of the Dragon Slayer Sword.
     *
     * @return The name of the sword
     */
    @Override
    public String getName(){
        return "Dragon Slayer Sword";
    }
}
