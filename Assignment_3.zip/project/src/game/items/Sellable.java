package game.items;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;

/**
 *  Interface representing items that can be sold by actors.
 * Created by:
 * @author Sia Yi Bin
 * Modified by:
 * Sia Yi Bin
 */
public interface Sellable {
    /**
     * Sells the item, removed the item to inventory of actor.
     *
     * @param actor The actor selling the item.
     * @param map The map that actor on.
     */
    String sell(Actor actor, GameMap map);

    /**
     * Retrieves the value of the item.
     *
     * @return the cost of item
     */
    int getValue();

    /**
     * Retrieves the name of the item.
     *
     * @return the name of item
     */
    String getName();
}
