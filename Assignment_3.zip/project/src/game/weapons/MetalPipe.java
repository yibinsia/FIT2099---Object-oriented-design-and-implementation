package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actions.ActionList;
import game.abilities.Status;
import game.actions.AttackAction;
import game.actions.SellAction;
import game.items.Sellable;

/**
 * Represents a metal pipe used as a weapon in the game.
 * This weapon item allows actors to perform melee attacks with enhanced damage.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin
 */
public class MetalPipe extends WeaponItem implements Sellable {
    /**
     * The amount of value of this item being sold.
     */
    private final int VALUE = 35;


    /**
     * Constructor for the Metal Pipe.
     * Initializes the pipe with basic weapon attributes.
     */
    public MetalPipe() {
        super("Metal Pipe", '!', 1, "strikes", 20);
    }

    /**
     * Sells the item and updates the actor's balance.
     *
     * This method allows an actor to sell the item (MetalPipe) for its value.
     * The value is added to the actor's balance, and the item is removed from the actor's inventory.
     *
     * @param actor The actor selling the item.
     * @param map The game map where the action is taking place.
     * @return A string describing the result of the sell action.
     */
    @Override
    public String sell(Actor actor, GameMap map) {
        int value = getValue();
        actor.addBalance(value);
        actor.removeItemFromInventory(this);
        return actor + " successfully sells a " + getName() + " for " + value + " credits.";
    }

    /**
     * Returns the value of the item.
     * @return The value of the item.
     */
    @Override
    public int getValue() {
        return VALUE;
    }

    /**
     * Returns the name of the item.
     *
     * @return The name of the item.
     */
    @Override
    public String getName() {
        return "Metal Pipes";
    }

    /**
     * Provides a list of actions that can be performed using the metal pipe when interacting with other actors.
     *
     * @param otherActor The actor who might be targeted with the pipe.
     * @param location   The location where the interaction is occurring.
     * @return An ActionList containing actions that involve using the metal pipe.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = super.allowableActions(location);
        actions.add(new AttackAction(otherActor, location.toString(), this));
        if (otherActor.hasCapability(Status.ALLIES)){
            actions.add(new SellAction(this));
        }
        return actions;
    }
}


