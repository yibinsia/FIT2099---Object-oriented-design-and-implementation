package game.spawners;

import edu.monash.fit2099.engine.positions.Location;

/**
 * Interface defining a spawner for creatures in a game.
 * Implementations of this interface are responsible for spawning creatures at specific locations.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public interface Spawner {
    /**
     * Attempts to spawn a creature at the given location.
     *
     * @param location The location where the creature might be spawned.
     */
    void spawn(Location location);
}
