package game.spawners;

import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.items.LargeFruit;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * LargeFruitSpawner is a class that implements the Spawner interface.
 * It is responsible for spawning LargeFruit items at random locations in the game.
 * Created by:
 * @author Shuntaro Yamada
 * Modified by:
 * Shuntaro Yamada
 */
public class LargeFruitSpawner implements Spawner {
    /**
     * Random object used to select random locations for spawning.
     */
    private Random random = new Random();

    /**
     * Attempts to spawn a LargeFruit at a random location.
     * It first creates a LargeFruit object, then gets a list of all exits from the given location.
     * It adds all neighboring locations to a list of available locations.
     * If there are any available locations, it selects one at random and adds the LargeFruit to that location.
     *
     * @param location The location where the LargeFruit might be spawned.
     */
    @Override
    public void spawn(Location location) {
        LargeFruit largeFruit = new LargeFruit();
        List<Exit> exits = location.getExits();
        List<Location> availableLocations = new ArrayList<>();

        for (Exit exit : exits) {
            Location neighbor = exit.getDestination();
            availableLocations.add(neighbor);
        }

        if (!availableLocations.isEmpty()) {
            int index = random.nextInt(availableLocations.size());
            Location dropLocation = availableLocations.get(index);
            dropLocation.addItem(largeFruit);
        }

    }
}
