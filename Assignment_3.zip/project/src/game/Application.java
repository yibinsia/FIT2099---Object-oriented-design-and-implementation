package game;

import java.util.*;

import edu.monash.fit2099.engine.positions.GameMap;
import game.actors.HumanoidFigure;
import game.actors.Player;
import game.spawners.*;
import game.weapons.MetalPipe;
import game.items.*;
import game.grounds.*;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.World;

/**
 * The main class to start the game.
 * Created by
 * @author Shuntaro Yamada
 * Modified by:
 * Sia Yi Bin, Shuntaro Yamada, Sheryl Lee, Ting Guang Xun
 */
public class Application {
    public static World world;
    public static HashMap<GameMap, HashMap<String, Object>> gameMapInfo;

    public static void main(String[] args) {

        world = new World(new Display());
        gameMapInfo = new HashMap<>();

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(),
                new Wall(), new Floor(), new Puddle(), new SaplingTree());

        // Polymorphia map (Original Moon)
        List<String> mapPolymorphia = Arrays.asList(
                "...~~~~.........~~~...........",
                "...~~~~.......................",
                "...~~~........................",
                ".....t........................",
                ".............#####............",
                ".............#___#...........~",
                ".............#___#..........~~",
                ".............##_##.........~~~",
                ".................~~........~~~",
                "................~~~~.......~~~",
                ".............~~~~~~~........~~",
                "......~.....~~~~~~~~.........~",
                ".....~~~...~~~~~~~~~..........",
                ".....~~~~~~~~~~~~~~~~........~",
                ".....~~~~~~~~~~~~~~~~~~~....~~");

        // Connascence map (New Moon)
        List<String> mapConnascence = Arrays.asList(
                "..........................~~~~",
                "..........................~~~~",
                "..........................~~~~",
                "~..........................~..",
                "~~...........#####............",
                "~~~..........#___#............",
                "~~~..........#___#............",
                "~~~..........##_##............",
                "~~~..................~~.......",
                "~~~~................~~~~......",
                "~~~~...............~~~~~......",
                "..~................~~~~.......",
                "....................~~........",
                ".............~~...............",
                "............~~~~..............");

        // Factory map
        List<String> mapTheStaticFactory = Arrays.asList(
                ".......",
                ".#####.",
                ".#___#.",
                ".#___#.",
                ".##_##.",
                ".......",
                ".......",
                ".......",
                ".......",
                "......."
        );

        // Create purchasable items
        Purchasable energyDrink = new EnergyDrink();
        Purchasable dragonSlayerSword = new DragonSlayerSword();
        Purchasable toiletPaperRoll = new ToiletPaperRoll();
        Purchasable theseus = new Theseus();
        Purchasable astley = new Astley();
        // Create arrays of purchasable items
        List<Purchasable> purchasableList = Arrays.asList(energyDrink, dragonSlayerSword, toiletPaperRoll, theseus, astley);

        // Create game maps
        GameMap polymorphia = new GameMap(groundFactory, mapPolymorphia);
        world.addGameMap(polymorphia);
        HashMap<String, Object> polymorphiaInfo = new HashMap<>();
        polymorphiaInfo.put("name", "Polymorphia");
        polymorphiaInfo.put("terminalLocation", polymorphia.at(15, 5));
        gameMapInfo.put(polymorphia, polymorphiaInfo);

        GameMap connascence = new GameMap(groundFactory, mapConnascence);
        world.addGameMap(connascence);
        HashMap<String, Object> connascenceInfo = new HashMap<>();
        connascenceInfo.put("name", "Connascence");
        connascenceInfo.put("terminalLocation", connascence.at(15, 5));
        gameMapInfo.put(connascence, connascenceInfo);

        GameMap theStaticFactory = new GameMap(groundFactory, mapTheStaticFactory);
        world.addGameMap(theStaticFactory);
        HashMap<String, Object> theStaticFactoryInfo = new HashMap<>();
        theStaticFactoryInfo.put("name", "the Static Factory");
        theStaticFactoryInfo.put("terminalLocation", theStaticFactory.at(3, 2)); // For small map
        gameMapInfo.put(theStaticFactory, theStaticFactoryInfo);

        // Create a computer terminal
        ComputerTerminal terminal = new ComputerTerminal(purchasableList, gameMapInfo);

        // Print the title of the game
        for (String line : FancyMessage.TITLE.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        // Add items and grounds to the game maps
        polymorphia.at(5, 8).addItem(new LargeBolt());
        polymorphia.at(11, 8).addItem(new MetalSheet());
        polymorphia.at(14, 10).addItem((new MetalPipe()));
        polymorphia.at(7, 11).addItem((new MetalPipe()));
        polymorphia.at(13, 9).setGround(new Crater(new SpiderSpawner()));
        polymorphia.at(14, 8).setGround(new Crater(new AlienBugSpawner()));
        polymorphia.at(4, 6).setGround(new Crater(new SuspiciousAstronautSpawner()));
        polymorphia.at(17,8).addItem(new Gold());
        polymorphia.at(17,9).addItem(new Pickles());
        polymorphia.at(15, 5).setGround(terminal);
        polymorphia.at(11, 2).setGround(new SaplingTree());

        theStaticFactory.at(3,2 ).setGround(terminal);
        theStaticFactory.at(3,9).addActor(new HumanoidFigure());

        connascence.at(15, 5).setGround(terminal);
        connascence.at(11,2).setGround(new Sprout());

        // Create a player and add it to the game map
        Player player = new Player("Intern", '@', 4);
        world.addPlayer(player, polymorphia.at(15, 5));
        world.run();
    }
}
