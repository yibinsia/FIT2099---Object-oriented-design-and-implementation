package game.behaviours;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actors.Behaviour;
import game.actions.AttackAction;
import game.Status;


/**
 * A behaviour that allows an actor to attack a hostile actor.
 */
public class AttackBehaviour implements Behaviour {

    /**
     * Returns an action for the actor to attack a hostile actor in a nearby location if possible,
     * returns nulls if no hostile actor found nearby.
     *
     * @param actor The actor performing the action
     * @param map   The game map
     * @return An action for the actor to attack a hostile actor in a nearby location, or null if no such actor is found
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {

        Location currentLocation = map.locationOf(actor);
        for (Exit exit : currentLocation.getExits()) {
            Location destination = exit.getDestination();
            if (destination.containsAnActor()) {
                Actor nearbyActor = destination.getActor();
                if (nearbyActor.hasCapability(Status.HOSTILE_TO_ENEMY)) {
                    return new AttackAction(nearbyActor, "nearby", actor.getIntrinsicWeapon());
                }
            }
        }
        return null;
    }
}

