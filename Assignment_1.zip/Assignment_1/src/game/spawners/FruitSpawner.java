package game.spawners;

import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.grounds.Maturetree;
import game.grounds.Wall;
import game.consumableItems.LargeFruit;
import game.consumableItems.SmallFruit;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Class representing a spawner for fruits.
 */
public class FruitSpawner extends Spawner {
    /**
     * Tree age counts
     */
    private Ground tree;
    private int age = 0;

    public FruitSpawner(Ground tree) {
        this.tree = tree;
    }
    /**
     * Spawns a fruit at the given location if the location is valid.
     * Replace the Inheritree to Maturetree after 5 ticks.
     * @param location The location to spawn the fruit
     * @param random   The random number generator
     */
    @Override
    public void spawn(Location location, Random random) {
        if (tree.getDisplayChar() == 't') {
            if (age < 5 && random.nextDouble() <= 0.3) {
                placeFruit(location, new SmallFruit());
            } else if (age >= 5) {
                location.setGround(new Maturetree());
            }
        } else if (tree.getDisplayChar() == 'T') {
            if (random.nextDouble() <= 0.2) {
                placeFruit(location, new LargeFruit());
            }
        }
        age++;
    }

    /**
     * Places either large or small fruit in a random adjacent location to the given location.
     * @param location The location from which to place the Large/Small fruit
     */
    private void placeFruit(Location location, Item fruit) {
        List<Exit> shuffledExits = new ArrayList<>(location.getExits());
        Collections.shuffle(shuffledExits);
        for (Exit exit : shuffledExits) {
            Location adjacentLocation = exit.getDestination();

            if (isValidLocationForFruit(adjacentLocation)) {
                adjacentLocation.addItem(fruit);
                return;
            }
        }
    }
    /**
     * Check is it able to places a fruit in a random adjacent location to the given location.
     * @param location The location from which to place the HuntsmanSpider
     */
    private boolean isValidLocationForFruit(Location location) {
        Ground ground = location.getGround();
        return !(ground instanceof Wall);
    }
}