package game.spawners;
import edu.monash.fit2099.engine.positions.Location;
import java.util.Random;

/**
 * Abstract class representing a spawner for items or actors.
 */
public abstract class Spawner {
    /**
     * Spawns an item or actor at the given location if the location is valid.
     *
     * @param location The location to spawn the item or actor
     * @param random   The random number generator
     */
    public abstract void spawn(Location location, Random random);
}
