package game.spawners;


import edu.monash.fit2099.engine.positions.Exit;
import edu.monash.fit2099.engine.positions.Location;
import game.actors.HuntsmanSpider;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Class representing a spawner for Huntsman spiders.
 */
public class HuntsmanSpiderSpawner extends Spawner {


    /**
     * Spawn a Huntsman spider at the given location if the location is valid.
     *
     * @param location The location to spawn the Huntsman spider
     * @param random   The random number generator
     */
    public void spawn(Location location, Random random) {
        if (random.nextDouble() <= 0.05) {
            placeHuntsmanSpider(location);
        }
    }

    /**
     * Places a HuntsmanSpider in a random adjacent location to the given location.
     * @param location The location from which to place the HuntsmanSpider
     */
    private void placeHuntsmanSpider(Location location) {
        List<Exit> shuffledExits = new ArrayList<>(location.getExits());
        Collections.shuffle(shuffledExits);

        for (Exit exit : shuffledExits) {
            Location adjacentLocation = exit.getDestination();

            if (isValidLocationForSpider(adjacentLocation)) {
                adjacentLocation.addActor(new HuntsmanSpider());
                return;
            }
        }
    }

    /**
     * Check is it able to place HuntsmanSpider in a random adjacent location to the given location.
     * @param location The location from which to place the HuntsmanSpider
     */
    private boolean isValidLocationForSpider(Location location) {
        return location.canActorEnter(null);
    }
}
