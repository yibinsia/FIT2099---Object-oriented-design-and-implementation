package game.items;

import edu.monash.fit2099.engine.items.Item;

/**
 * Class representing a large bolt item, able to be picked up by intern.
 */
public class LargeBolt extends Item {
    public LargeBolt() {
        super("Large Bolt", '+', true);
    }
}

