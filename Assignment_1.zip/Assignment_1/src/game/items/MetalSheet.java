package game.items;

import edu.monash.fit2099.engine.items.Item;

/**
 * Class representing a metal sheet item, able to be picked up by intern.
 */
public class MetalSheet extends Item {
    public MetalSheet() {
        super("Metal Sheet", '%', true); // Name, displayChar, and portability
    }
}
