package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.GameMap;
import game.consumableItems.Consumable;

/**
 * An action that allows an actor to consume an item and heal for a certain amount of HP.
 */
public class ConsumeAction extends Action {
    private Consumable consumable;

    public ConsumeAction(Consumable consumable) {
        this.consumable = consumable;
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        consumable.consumeby(actor);
        return actor + " consumed " + consumable + " and gained " + consumable.getHealAmount() + " HP.";
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " consume " + consumable;
    }
}

