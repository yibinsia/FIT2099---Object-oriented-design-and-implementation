package game.consumableItems;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import game.Ability;
import game.actions.ConsumeAction;

/**
 * Class representing a small fruit item, able to be picked up by intern,
 * able to be consumed by intern for increase hit points by 1.
 */
public class SmallFruit extends Item implements Consumable {
    private int healAmount = 1;
    public SmallFruit() {super("Small Fruit", 'o', true);}

    @Override
    public void consumeby(Actor actor) {
        actor.heal(healAmount);
        actor.removeItemFromInventory(this);
    }

    @Override
    public int getHealAmount() {
        return healAmount;
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}