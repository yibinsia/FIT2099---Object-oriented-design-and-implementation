package game.consumableItems;

import edu.monash.fit2099.engine.actors.Actor;

/**
 * Interface representing a consumable item.
 */
public interface Consumable {
    /**
     * Consume the item.
     *
     * @param actor The actor consuming the item.
     */
    void consumeby(Actor actor);

    /**
     * Get the amount of hitpoints the consumable restores.
     *
     * @return The amount of hitpoints the consumable restores.
     */
    int getHealAmount();
}
