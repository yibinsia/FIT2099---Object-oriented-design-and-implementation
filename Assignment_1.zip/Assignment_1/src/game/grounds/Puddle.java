package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;

public class Puddle extends Ground {
    public Puddle() {
        super('~');
    }
}
