package game.grounds;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.FruitSpawner;
import game.spawners.Spawner;

import java.util.Random;

/**
 * Class representing a ground type object on the game map, able to spawn small fruit.
 *
 */
public class Inheritree extends Ground {
    private Random random = new Random();
    private Spawner spawner;

    public Inheritree() {
        super('t');
        this.spawner = new FruitSpawner(this);
    }

    /**
     * Update the tree's growth and fruit dropping mechanism.
     *
     * @param location The location of the Inheritree
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        spawner.spawn(location, random);
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
