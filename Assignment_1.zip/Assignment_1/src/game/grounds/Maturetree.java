

package game.grounds;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.FruitSpawner;
import game.spawners.Spawner;

import java.util.Random;

/**
 * Class representing a mature stage of inheritree, able to spawn large fruit.
 *
 */
public class Maturetree extends Ground {
    private Random random = new Random();
    private Spawner spawner;

    public Maturetree() {
        super('T');
        this.spawner = new FruitSpawner(this);
    }

    /**
     * Update the tree's growth and fruit dropping mechanism.
     *
     * @param location The location of the Maturetree
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        spawner.spawn(location, random);
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}
