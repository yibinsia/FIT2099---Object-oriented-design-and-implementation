package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.positions.Ground;

import game.spawners.HuntsmanSpiderSpawner;
import game.spawners.Spawner;

import java.util.Random;

/**
 * Class representing a ground type object on the game map, able to spawn Huntsman Spider.
 */
public class Crater extends Ground {
    private Random random = new Random();
    private Spawner spawner;

    public Crater() {
        super('u');
        this.spawner = new HuntsmanSpiderSpawner();
    }

    /**
     * Update the spawning mechanism of Huntsman spiders around the crater
     *
     * @param location The location of the crater.
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        spawner.spawn(location, random);
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}

