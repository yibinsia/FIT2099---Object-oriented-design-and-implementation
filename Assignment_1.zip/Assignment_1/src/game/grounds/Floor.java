package game.grounds;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.positions.Ground;
import game.Status;

/**
 * A class that represents the floor inside a building.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by: Sia Yi Bin
 *
 */
public class Floor extends Ground {
    public Floor() {
        super('_');
    }

    /**
     * Make sure the hostile cannot enter the spaceship.
     * @param actor the Actor to check
     * @return true if actor has HOSTILE_TO_ENEMY
     */
    @Override
    public boolean canActorEnter(Actor actor) {
        return actor.hasCapability(Status.HOSTILE_TO_ENEMY);
    }
}
