package game.weapons;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import edu.monash.fit2099.engine.positions.Location;
import game.actions.AttackAction;

/**
 * Class representing a metal pipe weapon item, able to be picked up by intern,
 * able to be armed by intern as weapon.
 */
public class MetalPipe extends WeaponItem {
    public MetalPipe(){super("Metal Pipe", '!',1, "smash", 20);}

    /**
     * Returns a list of actions that the MetalPipe allows other actors to perform on it.
     * @param otherActor the Actor that might be performing an action
     * @param location the Location where the action is being performed
     * @return an ActionList object containing the allowable actions for the MetalPipe
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = new ActionList();
        actions.add(new AttackAction(otherActor,"nearby", this));
        return actions;
    }
}
