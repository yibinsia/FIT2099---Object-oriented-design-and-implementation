package edu.monash.fit2099.demo.conwayslife;

public enum Status {
	ALIVE, DEAD
}
