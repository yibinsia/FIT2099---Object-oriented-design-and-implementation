package game.grounds;

import edu.monash.fit2099.engine.positions.Location;
import game.spawners.SmallFruitSpawner;
import game.spawners.Spawner;

import java.util.Random;

/**
 * Represents a sapling tree in the game environment.
 * Saplings are young trees that have the potential to grow into mature trees. They can occasionally drop small fruits
 * and will mature into a MatureTree after reaching a certain age. This transformation is accompanied by changes
 * in their behavior and potentially their appearance in the game.
 */
public class SaplingTree extends Inheritree {
    /**
     * Random number generator to determine the probability of fruit dropping.
     */
    private Random random = new Random();

    /**
     * Spawner for small fruits, responsible for creating and placing small fruits in the game world.
     */
    private Spawner smallFruitSpawner = new SmallFruitSpawner();
    /**
     * The current age of the sapling, initialized at 0 and increases over time.
     */
    private int age = 0;
    /**
     * Constructor for the SaplingTree class.
     * Initializes the sapling with a display character 't', representing its visual appearance on the game map.
     */
    public SaplingTree(){
        super('t');
    }
    /**
     * Simulates the passage of time for the sapling tree.
     * This method handles the growth of the sapling, its potential to spawn small fruits, and its transformation
     * into a mature tree once it reaches the age of 5.
     *
     * @param location The current location of the sapling on the game map.
     */
    public void tick(Location location) {

        age++;
        float chance = random.nextFloat();

        if(age==5){
            location.setGround(new MatureTree());
        }
        if (chance<=0.3){
            smallFruitSpawner.spawn(location);
        }


    }
}
