package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.actions.ActionList;
import game.actions.PurchaseAction;
import game.items.Purchasable;
import java.util.List;

/**
 * Represents a ComputerTerminal ground type in the game environment.
 * ComputerTerminal allows surrounding actors to purchase item from it
 * Created by:
 * @author Shuntaro Yamada
 */
public class ComputerTerminal extends Ground{
    private List<Purchasable> purchasableItems;  // List of items that can be purchased at this terminal

    /**
     * Constructor.
     *
     * @param purchasableItems the list of items that is purchasable
     */
    public ComputerTerminal(List<Purchasable> purchasableItems) {
        super('=');
        this.purchasableItems = purchasableItems;
    }


    /**
     * Returns an Action list that contains each PurchaseAction for each purchasableItems.
     *
     * @param actor the Actor acting
     * @param location the current Location
     * @param direction the direction of the Ground from the Actor
     * @return a collection of Actions
     */
    @Override
    public ActionList allowableActions(Actor actor, Location location, String direction) {
        ActionList actions = new ActionList();
        for (Purchasable item : purchasableItems) {
            actions.add(new PurchaseAction(item));
        }
        return actions;
    }
}
