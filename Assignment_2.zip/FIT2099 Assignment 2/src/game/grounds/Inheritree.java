package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;

/**
 * Abstract base class representing a tree-like structure in the game environment.
 * This class includes basic properties common to tree-like entities, such as age,
 * and requires implementing classes to define specific behaviors that occur over time.
 * Created by:
 * @author Shuntao Yamada
 */
public abstract class Inheritree extends Ground {

    /**
     * Constructor for Inheritree.
     * Initializes the tree-like entity with a specific display character.
     *
     * @param displayChar the character to display this entity on the map
     */
    public Inheritree(char displayChar) {
        super(displayChar);
    }

    /**
     * Abstract method that dictates how the tree-like entity behaves as time passes.
     * This method must be implemented by subclasses to define specific growth behaviors or other time-based effects.
     *
     * @param currentLocation the current location of the entity on the game map
     */
    @Override
    public abstract void tick(Location currentLocation);

}



