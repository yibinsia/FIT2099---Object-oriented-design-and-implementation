package game.grounds;
import edu.monash.fit2099.engine.positions.Location;

import java.util.Random;

import game.spawners.LargeFruitSpawner;
import game.spawners.Spawner;

/**
 * Represents a mature tree that can spawn large fruits.
 * This class manages the lifecycle and fruit-spawning behavior of a mature tree in the game environment.
 * The MatureTree has an inherent ability to potentially drop large fruits at a specified probability each game tick.
 * Created by:
 * @author Shuntaro Yamada
 */
public class MatureTree extends Inheritree {
    /**
    * Random number generator to determine the probability of fruit dropping.
    */
    private Random random = new Random();

    /**
     * Spawner responsible for creating large fruits.
     */
    private Spawner bigFruitSpawner = new LargeFruitSpawner();
    /**
     * Age of the tree, starts at maturity.
     */
    private int age = 5;
    /**
     * Constructor for the MatureTree class.
     * Initializes the tree with a display character 'T'.
     */
    public MatureTree() {
        super('T');
    }
    /**
     * Simulates a single time unit passage on this tree.
     * It potentially spawns a large fruit based on a predefined chance.
     *
     * @param location The location of the tree within the game map.
     */
    public void tick(Location location) {
        age++;
        float chance = random.nextFloat();
        if (chance <= 0.2) {
            bigFruitSpawner.spawn(location);
        }

    }
}

