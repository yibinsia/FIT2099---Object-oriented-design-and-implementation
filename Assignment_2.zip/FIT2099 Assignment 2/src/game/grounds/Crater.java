package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.positions.Location;
import game.spawners.Spawner;

/**
 * Represents a Crater ground type in the game environment.
 * Craters can potentially spawn creatures at each game tick if conditions are met.
 * Created by:
 * @author Shuntaro Yamada
 */
public class Crater extends Ground{
    /**
     * The spawner used to potentially spawn creatures in this crater.
     */
    private game.spawners.Spawner Spawner;

    /**
     * Constructor for the Crater class.
     * Initializes the crater with a spawner that can spawn creatures in it.
     *
     * @param Spawner the Spawner instance responsible for handling creature spawns in this crater
     */
    public Crater(Spawner Spawner){
        super('u');
        this.Spawner = Spawner;
    }

    /**
     * Executes at every tick of the game to perform operations specific to craters, such as attempting to spawn creatures.
     * It delegates the spawning logic to the spawner provided during construction.
     *
     * @param location the location of this piece of ground within the game map
     */
    @Override
    public void tick(Location location) {
        super.tick(location);
        // Check if there is no actor here and maybe spawn a spider
        Spawner.spawn(location);
    }
}
