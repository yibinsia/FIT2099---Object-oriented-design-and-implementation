package game.grounds;

import edu.monash.fit2099.engine.positions.Ground;
import edu.monash.fit2099.engine.actors.Actor;
import game.abilities.Ability;

/**
 * A class that represents the floor inside a building.
 * Created by:
 * @author Riordan D. Alfredo
 * Modified by:
 * Shuntaro Yamada
 */
public class Floor extends Ground {
    public Floor() {
        super('_');
    }

    /**
     * Determines if an actor can enter this floor area.
     * Only actors with the ENTER_SPACESHIP capability are allowed to enter,
     * indicating specific accessibility conditions, possibly related to story or character privileges.
     *
     * @param actor the actor attempting to enter this area
     * @return true if the actor has the ENTER_SPACESHIP capability, false otherwise
     */
    @Override
    public boolean canActorEnter(Actor actor){
        return actor.hasCapability((Ability.ENTER_SPACESHIP));
    }


}
