package game;

import java.util.Arrays;
import java.util.List;

import game.actors.AlienBug;
import game.actors.Player;
import game.spawners.*;
import game.weapons.MetalPipe;
import game.items.*;
import game.grounds.*;
import edu.monash.fit2099.engine.displays.Display;
import edu.monash.fit2099.engine.positions.FancyGroundFactory;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.positions.World;


/**
 * The main class to start the game.
 */
public class Application {

    public static void main(String[] args) {

        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(),
                new Wall(), new Floor(), new Puddle(), new SaplingTree());

        List<String> map = Arrays.asList(
                "...~~~~.........~~~...........",
                "...~~~~.......................",
                "...~~~........................",
                ".....t........................",
                ".............#####............",
                ".............#___#...........~",
                ".............#___#..........~~",
                ".............##_##.........~~~",
                ".................~~........~~~",
                "................~~~~.......~~~",
                ".............~~~~~~~........~~",
                "......~.....~~~~~~~~.........~",
                ".....~~~...~~~~~~~~~..........",
                ".....~~~~~~~~~~~~~~~~........~",
                ".....~~~~~~~~~~~~~~~~~~~....~~");


        GameMap gameMap = new GameMap(groundFactory, map);
        world.addGameMap(gameMap);

        for (String line : FancyMessage.TITLE.split("\n")) {
            new Display().println(line);
            try {
                Thread.sleep(200);
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }
        Purchasable energyDrink = new EnergyDrink();
        Purchasable dragonSlayerSword = new DragonSlayerSword();
        Purchasable toiletPaperRoll = new ToiletPaperRoll();
        ComputerTerminal terminal = new ComputerTerminal(Arrays.asList(energyDrink, dragonSlayerSword, toiletPaperRoll));

        gameMap.at(15, 5).setGround(terminal);
        gameMap.at(5, 8).addItem(new LargeBolt());
        gameMap.at(11, 8).addItem(new MetalSheet());
        gameMap.at(14, 10).addItem((new MetalPipe()));
        gameMap.at(7, 11).addItem((new MetalPipe()));
        gameMap.at(13, 9).setGround(new Crater(new SpiderSpawner()));
        gameMap.at(14, 8).setGround(new Crater(new AlienBugSpawner()));
        gameMap.at(4, 6).setGround(new Crater(new SuspiciousAstronautSpawner()));
        gameMap.at(17,8).addItem(new Gold());
        gameMap.at(17,9).addItem(new Pickles());

        Player player = new Player("Intern", '@', 4);
        world.addPlayer(player, gameMap.at(15, 6));

        world.run();
    }
}
