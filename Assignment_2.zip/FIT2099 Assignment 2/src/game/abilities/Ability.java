package game.abilities;

/**
 * Enum representing various abilities that game characters can possess.
 * These abilities can be used to determine the actions and interactions a character can perform.
 */
public enum Ability {
    /**
     * Ability to enter a spaceship.
     * Characters with this ability can interact with spaceships in a way that those without cannot.
     */
    ENTER_SPACESHIP,
    /**
     * Ability to eat.
     * Characters with this ability can consume food items to gain benefits or effects.
     */
    EAT,
    /**
     * Ability to have a wallet.
     * Characters with this ability can hold and manage currency for purchasing items or services.
     */
    HAS_WALLET
}
