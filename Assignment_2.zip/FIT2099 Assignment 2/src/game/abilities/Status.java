package game.abilities;

/**
 * Enum representing various statuses that game characters can possess.
 * These statuses can be used to determine the behavior and interactions of a character.
 */
public enum Status {
    /**
     * Status indicating that the character is hostile to enemies.
     * Characters with this status will behave aggressively towards enemy characters.
     */
    HOSTILE_TO_ENEMY,
}
