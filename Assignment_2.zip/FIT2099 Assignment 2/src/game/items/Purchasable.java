package game.items;
import game.actions.PurchaseAction;
import edu.monash.fit2099.engine.actors.Actor;

import game.actions.PurchaseAction;

/**
 * Interface representing items that can be purchased by actors.
 */
public interface Purchasable {

    /**
     * Purchases the item, adding the item to inventory of actor.
     *
     * @param actor The actor purchasing the item.
     */
    String purchase(Actor actor);

    /**
     * Retrieves the cost of the item.
     *
     * @return the cost of item
     */
    int getCost();

    /**
     * Retrieves the name of the item.
     *
     * @return the name of item
     */
    String getName();
}
