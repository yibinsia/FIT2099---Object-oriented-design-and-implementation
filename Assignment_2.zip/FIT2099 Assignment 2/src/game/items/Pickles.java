package game.items;
import edu.monash.fit2099.engine.items.Item;
import game.abilities.Ability;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import game.actions.ConsumeAction;
import java.util.Random;

/**
 * Class representing a Pickles item, able to be picked up by intern
 * able to be consumed by intern for increase hit points by 1 or
 * decrease hit points by 1.
 */
public class Pickles extends Item implements Consumable{

    /**
     * The amount of hit points can be increased or decreased per consume.
     */
    private final int HEALPOINTS = 1;

    /**
     * Constructor for Pickles.
     * Initializes the pickles with a display character 'n'.
     */
    public Pickles() {super("a jar of pickles", 'n', true);}

    /**
     * Randomly decide the heal amount is 1 or -1.
     * @return An integer representing the heal or hurt amount
     */
    public int getHealAmount() {
        Random random = new Random();
        boolean isExpired = random.nextBoolean(); // 50% chance of being expired
        if (isExpired) {
            // If it's past its expiry date, the Intern will be hurt by 1 point
            return (-HEALPOINTS);
        } else {
            // Otherwise, the Intern will be healed by 1 point
            return HEALPOINTS;
        }
    }

    public String getConsumableName(){return this.toString();}

    public String menustring(){
        return " consumes " + getConsumableName();
    }

    /**
     * Heal the intern if the pickles hasn't expired, hurt the intern
     * if the pickles has expired.
     * @param owner The actor carrying pickles
     * @return A string for description after consumed pickles
     */
    @Override
    public String consume(Actor owner) {
        int healAmount = getHealAmount();
        owner.removeItemFromInventory(this);
        if (healAmount > 0) {
            // If the pickles are not expired, heal the owner
            owner.heal(healAmount);
            return owner + " consumes " + getConsumableName() + " and gains " + healAmount + " HP.";
        } else {
            // If the pickles are expired, hurt the owner
            owner.hurt(Math.abs(healAmount));
            return owner + " consumes " + getConsumableName() + " and loses " + Math.abs(healAmount) + " HP.";
        }
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}

