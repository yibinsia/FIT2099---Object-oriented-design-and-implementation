package game.items;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;

import game.actions.ConsumeAction;
import game.abilities.Ability;

/**
 * Class representing a Gold item, able to be picked up by intern
 * able to be added to the wallet of intern and increase 10 credits.
 */
public class Gold extends Item implements Consumable{

    /**
     * The amount of credit can be increased to the wallet per take.
     */
    private final int CREDIT_AMOUNT = 10;

    /**
     * Constructor for Gold.
     * Initializes the gold with a display character '$'.
     */
    public Gold(){
        super("a pot of gold", '$', true);
    }

    public int getHealAmount(){return this.CREDIT_AMOUNT;}

    public String getConsumableName(){return this.toString();}

    public String menustring(){
        return " takes " + getConsumableName();
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param owner The actor carrying gold
     * @return A string for description after taken the gold
     */
    @Override
    public String consume(Actor owner){
        owner.addBalance(this.CREDIT_AMOUNT);
        owner.removeItemFromInventory(this);
        return owner + " takes " + getConsumableName() + " and earns " + CREDIT_AMOUNT + " credit.";
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.HAS_WALLET)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}
