package game.items;
import edu.monash.fit2099.engine.items.Item;
/**
 * Represents a large bolt, typically used as a crafting component or trade item within the game.
 */
public class LargeBolt extends Item{
    public LargeBolt(){
        super ("Large Bolt", '+', true);
    }
}
