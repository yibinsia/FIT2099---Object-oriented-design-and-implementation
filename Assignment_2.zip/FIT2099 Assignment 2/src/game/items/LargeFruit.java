package game.items;
import game.abilities.Ability;
import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.actors.Actor;
import game.actions.ConsumeAction;
import edu.monash.fit2099.engine.items.Item;


/**
 * A class that represents an Item with healing effect
 */

public class LargeFruit extends Item implements Consumable {

    /**
     * The amount of hit points that this item can heal
     */
    public final int HEALPOINTS = 2;

    /**
     * Constructor for LargeFruit.
     * Initializes the large fruit with a display character '0'.
     */
    public LargeFruit(){
        super("Big Fruit", '0', true);
    }
    public int getHealAmount(){
        return this.HEALPOINTS;
    }

    public String getConsumableName(){
        return this.toString();
    }
    public String menustring(){
        return " consumes " + getConsumableName();
    }

    /**
     * Heal the intern by 2 hit points after consumed large fruit
     * @param owner The actor carrying large fruit
     * @return A string for description after consumed large fruit
     */
    @Override
    public String consume(Actor owner){
        owner.heal(this.HEALPOINTS);
        owner.removeItemFromInventory(this);
        return owner + " consumes " + getConsumableName() + " and gains " + HEALPOINTS + " HP.";
    }

    /**
     * Returns a list of allowable actions for the given actor.
     * @param actor The actor for which to return allowable actions
     * @return A list of allowable actions for the given actor
     */
    @Override
    public ActionList allowableActions(Actor actor) {
        ActionList actions = new ActionList();
        if (actor.hasCapability(Ability.EAT)) {
            actions.add(new ConsumeAction(this));
        }
        return actions;
    }
}
