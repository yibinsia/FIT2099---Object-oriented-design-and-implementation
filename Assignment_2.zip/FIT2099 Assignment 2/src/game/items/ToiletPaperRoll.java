package game.items;
import edu.monash.fit2099.engine.items.Item;
import game.actions.PurchaseAction;
import edu.monash.fit2099.engine.actors.Actor;

/**
 * ToiletPaperRoll is a class that represents a purchasable item in the game.
 * This class extends the Item abstract class and implements the Purchasable interface.
 */
public class ToiletPaperRoll extends Item implements Purchasable{
    /**
     * The normal cost of the ToiletPaperRoll.
     */
    private static final int NORMAL_COST = 5;
    /**
     * The discounted cost of the ToiletPaperRoll.
     */
    private static final int DISCOUNTED_COST = 1;
    /**
     * Constructor for the ToiletPaperRoll class.
     * Initializes the item with the name "Toilet Paper Roll", the character 's', and sets it as portable.
     */
    public ToiletPaperRoll(){
        super("Toilet Paper Roll", 's', true);
    }

    /**
     * Executes the purchase of the ToiletPaperRoll by an actor.
     * If the actor has enough balance, the cost of the ToiletPaperRoll is deducted from the actor's balance,
     * and the ToiletPaperRoll is added to the actor's inventory.
     * @param actor The actor that attempts to purchase the ToiletPaperRoll.
     * @return A string that represents the result of the purchase attempt.
     */
    @Override
    public String purchase(Actor actor){
        int cost = getCost();
        if (actor.getBalance() >= cost){
            actor.deductBalance(cost);
            actor.addItemToInventory(this);
            return actor + " successfully purchased a " +getName()+" for " + cost + " credits.";
        }
        else{
            return "Not enough credits to purchase a "+getName()+".";
        }
    }

    /**
     * Returns the cost of the ToiletPaperRoll.
     * There is a 75% chance that the cost will be the discounted cost, otherwise it will be the normal cost.
     * @return The cost of the ToiletPaperRoll.
     */
    @Override
    public int getCost(){
        if (Math.random() <= 0.75){
            return DISCOUNTED_COST;
        }
        return NORMAL_COST;
    }

    /**
     * Returns the name of the ToiletPaperRoll.
     * @return The name of the ToiletPaperRoll.
     */
    @Override
    public String getName() {
        return "Toilet Paper Roll";
    }

}
