package game.items;
import edu.monash.fit2099.engine.items.Item;

/**
 * Represents a metal sheet, typically used as a crafting component or defensive gear within the game.
 */
public class MetalSheet extends Item {
    public MetalSheet() {
        super("Metal Sheet", '%', true);
    }
}
