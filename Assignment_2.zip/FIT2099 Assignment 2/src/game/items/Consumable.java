package game.items;
import edu.monash.fit2099.engine.actors.Actor;

/**
 * Interface representing items that can be consumed by actors.
 * Consumables can apply effects, such as healing, when used by an actor.
 */
public interface Consumable {
    /**
     * Consumes the item, applying its effects to the actor.
     *
     * @param actor The actor consuming the item.
     */
    String consume(Actor actor);

    /**
     * Retrieves the amount of health the item restores when consumed.
     *
     * @return the healing amount
     */
    int getHealAmount();

    /**
     * Gets the name of the consumable item.
     *
     * @return the name of the consumable
     */
    String getConsumableName();

    /**
     * Gets the string to be display on the menu of the consumable item.
     *
     * @return the string to be display on the menu
     */
    String menustring();
}

