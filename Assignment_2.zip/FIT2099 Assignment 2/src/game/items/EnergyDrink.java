package game.items;

import edu.monash.fit2099.engine.actions.ActionList;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.actors.Actor;
import game.actions.ConsumeAction;
import game.actions.PurchaseAction;
/**
 * Represents an Energy Drink item in the game that actors can consume to recover health or purchase from stores.
 * This item serves dual roles, both as a health item that can be consumed to regain hit points, and as an item that
 * can be bought and sold, with its cost dynamically determined at the point of sale.
 */
public class EnergyDrink extends Item implements Consumable, Purchasable{
    private static final int BASE_COST = 10;   // Base cost of the Energy Drink
    private int healAmount = 1;    // Amount of health the Energy Drink restores when consumed

    /**
     * Constructor for the Energy Drink.
     * Initializes the Energy Drink with its name, display character, and portability.
     */
    public EnergyDrink(){
        super("Energy Drink", '*', true);
    }
    /**
     * Consumes the Energy Drink, increasing the actor's health by a specified amount and removing it from inventory.
     *
     * @param actor The actor consuming the Energy Drink
     * @return A string description of the consumption action and its effects
     */
    @Override
    public String consume(Actor actor){
        actor.heal(healAmount);
        actor.removeItemFromInventory((this));
        return actor + " drinks an " + getConsumableName() + " and gains " + healAmount + " health.";
    }
    /**
     * Retrieves the amount of health the Energy Drink restores.
     *
     * @return The amount of health restored by the Energy Drink
     */
    @Override
    public int getHealAmount(){
        return healAmount;
    }
    /**
     * Gets the name of the consumable for display in menus.
     *
     * @return The name of the consumable
     */
    @Override
    public String getConsumableName(){
        return "Energy Drink";
    }
    /**
     * Gets the name of the items for purchasable.
     *
     * @return The name of the purchasable
     */
    @Override
    public String getName(){
        return "Energy Drink";
    }
    /**
     * Provides a description of the menu option for consuming the Energy Drink.
     *
     * @return A string for menu display indicating the health recovery action
     */
    @Override
    public String menustring() {
        return " drinks " + getConsumableName() + " to recover " + getHealAmount() + " health points";
    }
    /**
     * Calculates the cost of the Energy Drink, which may vary depending on random chance.
     *
     * @return The cost of the Energy Drink, possibly doubled at a 20% chance
     */
    @Override
    public int getCost(){
        if (Math.random() <= 0.2){
            return BASE_COST*2;
        } else {
            return BASE_COST;
        }
    }
    /**
     * Manages the purchase of the Energy Drink by an actor, checking for sufficient funds and transferring the item.
     *
     * @param actor The actor attempting to purchase the Energy Drink
     * @return A string indicating whether the purchase was successful or failed due to insufficient funds
     */
    @Override
    public String purchase(Actor actor){
        int cost = getCost();
        if (actor.getBalance() >= cost){
            actor.deductBalance(cost);
            actor.addItemToInventory(this);
            return actor + " successfully purchased an " + getName() + " for " + cost + " credits.";
        }
        return "Not enough credits to purchase an " + getName() + ".";
    }
    /**
     * Generates a list of actions that can be performed with the Energy Drink when held by an actor, specifically consumption.
     *
     * @param actor The actor holding the Energy Drink
     * @return An ActionList containing the consume action
     */
    @Override
    public ActionList allowableActions(Actor actor){
        ActionList actions = new ActionList();
        actions.add(new ConsumeAction(this));
        return actions;
    }

}