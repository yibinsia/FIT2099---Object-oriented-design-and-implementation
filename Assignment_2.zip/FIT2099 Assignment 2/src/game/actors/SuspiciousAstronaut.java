package game.actors;

import edu.monash.fit2099.engine.actors.Behaviour;
import edu.monash.fit2099.engine.weapons.IntrinsicWeapon;
import game.behaviours.AttackBehaviour;
import game.behaviours.WanderBehaviour;

import java.util.HashMap;
import java.util.Map;

/**
 * SuspiciousAstronaut is a type of Enemy in the game. It has the ability to attack other actors
 * and wander around the map. It has a very high hit point value and a powerful intrinsic weapon.
 */
public class SuspiciousAstronaut extends Enemy {

    /**
     * Constructor. Initializes the SuspiciousAstronaut with a name, the character 'ඞ',
     * and 99 hit points. It also adds the capabilities to attack other actors and wander.
     */
    public SuspiciousAstronaut() {
        super("Suspicious Astronaut", 'ඞ', 99);
        this.behaviours.put(1, new AttackBehaviour());
        this.behaviours.put(999, new WanderBehaviour());
    }

    /**
     * Defines the intrinsic weapon for the SuspiciousAstronaut, which is used when it attacks.
     * The weapon has a very high damage potential and a 100% hit chance.
     *
     * @return the intrinsic weapon with damage potential and attack verb
     */
    @Override
    public IntrinsicWeapon getIntrinsicWeapon() {
        // 100 hit chance implemented in the weapon's effect
        return new IntrinsicWeapon(Integer.MAX_VALUE, "kills", 100);
    }
}