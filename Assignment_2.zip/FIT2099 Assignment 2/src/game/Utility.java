package game;

import java.util.Random;

/**
 * A class for generating random integer
 */
public class Utility {
    /**
     * A method to generate an integer between the lower and upper bound given
     * @param digitNum   the lower bound of the range
     */
    public static String generateRandomInt(int digitNum){
        Random random = new Random();
        String retString = "";

        for(int i=0; i<digitNum; i++){
            int randomInt = random.nextInt(10);
            String randomIntString = String.valueOf(randomInt);
            retString += randomIntString;
        }

        return retString;
    }
}

