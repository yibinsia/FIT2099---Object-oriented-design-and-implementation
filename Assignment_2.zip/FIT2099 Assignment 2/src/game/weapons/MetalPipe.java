package game.weapons;

import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.weapons.WeaponItem;
import edu.monash.fit2099.engine.positions.Location;
import edu.monash.fit2099.engine.actions.ActionList;
import game.actions.AttackAction;

/**
 * Represents a metal pipe used as a weapon in the game.
 * This weapon item allows actors to perform melee attacks with enhanced damage.
 * Created by:
 * @author Shuntao Yamada
 */
public class MetalPipe extends WeaponItem {
    /**
     * Constructor for the Metal Pipe.
     * Initializes the pipe with basic weapon attributes.
     */
    public MetalPipe() {
        super("Metal Pipe", '!', 1, "strikes", 20);
    }

    /**
     * Provides a list of actions that can be performed using the metal pipe when interacting with other actors.
     *
     * @param otherActor The actor who might be targeted with the pipe.
     * @param location   The location where the interaction is occurring.
     * @return An ActionList containing actions that involve using the metal pipe.
     */
    @Override
    public ActionList allowableActions(Actor otherActor, Location location) {
        ActionList actions = super.allowableActions(location);
        actions.add(new AttackAction(otherActor, location.toString(), this));
        return actions;
    }
}


