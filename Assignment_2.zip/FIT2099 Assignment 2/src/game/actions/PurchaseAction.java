package game.actions;
import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.actors.Actor;
import edu.monash.fit2099.engine.items.Item;
import edu.monash.fit2099.engine.positions.GameMap;
import game.items.Purchasable;

/**
 * Class representing a purchase action in a game.
 * This action allows an actor to purchase an item using credit.
 */
public class PurchaseAction extends Action {
    /**
     * The item that is to be purchased
     */
    private Purchasable item;

    /**
     * Constructor for specifying a purchasableItem
     *
     * @param item    the item that is to be purchased
     */
    public PurchaseAction(Purchasable item){
        this.item = item;
    }


    /**
     * Execute the purchase action.
     *
     * @param actor the actor performing the purchase
     * @param map   the game map, used to apply the results of the purchase
     * @return a string describing the outcome of the purchase
     */
    @Override
    public String execute(Actor actor, GameMap map){
        return item.purchase(actor);
    }


    /**
     * Provides a description of the action for the menu.
     *
     * @param actor the actor performing the purchase action
     * @return a string describing the action for display in menus
     */
    @Override
    public String menuDescription(Actor actor) {
        return "purchases " + item.getName() + " for " + item.getCost() + " credits";
    }
}
