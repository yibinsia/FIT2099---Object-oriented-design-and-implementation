package game.actions;

import edu.monash.fit2099.engine.actions.Action;
import edu.monash.fit2099.engine.positions.GameMap;
import edu.monash.fit2099.engine.actors.Actor;
import game.items.Consumable;

/**
 * Class representing a consume action in a game.
 * This action allows an actor to consume a consumable item, typically for health recovery.
 */
public class ConsumeAction extends Action{

    /**
     * The consumable item to be consumed.
     */
    private Consumable consumable;

    /**
     * Constructor.
     *
     * @param consumable the consumable item to be consumed
     */
    public ConsumeAction(Consumable consumable){
        this.consumable = consumable;
    }

    /**
     * Executes the consume action, applying effects such as healing to the actor.
     *
     * @param actor the actor performing the consume action
     * @param map   the game map, potentially used to apply effects or changes resulting from consumption
     * @return a string describing the actor consuming the item and any effects that occur as a result
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        return consumable.consume(actor);
    }

    /**
     * Provides a description of the consume action for the menu.
     *
     * @param actor the actor who can perform the consume action
     * @return a string describing the action for display in menus, including the potential health recovery
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + consumable.menustring();
    }
}

