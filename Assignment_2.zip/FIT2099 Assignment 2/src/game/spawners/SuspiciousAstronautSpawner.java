package game.spawners;

import edu.monash.fit2099.engine.positions.Location;
import game.actors.SuspiciousAstronaut;

import java.util.Random;

/**
 * SuspiciousAstronautSpawner is a class that implements the Spawner interface for spawning SuspiciousAstronaut actors in the game.
 * SuspiciousAstronauts are spawned at a specified location based on a probability check.
 */
public class SuspiciousAstronautSpawner implements Spawner {

    /**
     * The chance of a SuspiciousAstronaut spawning at a given location during a spawn attempt.
     */
    private static final double SPAWN_CHANCE = 0.05;

    /**
     * Random number generator used to determine if a SuspiciousAstronaut spawns.
     */
    private Random random = new Random();

    /**
     * Attempts to spawn a SuspiciousAstronaut at a given location if the conditions are met.
     * The conditions for spawning a SuspiciousAstronaut are that the location must not currently contain an actor
     * and a random number must be less than the defined SPAWN_CHANCE.
     *
     * @param location The location where the SuspiciousAstronaut might be spawned.
     */
    @Override
    public void spawn(Location location){
        if (!location.containsAnActor() && random.nextDouble() < SPAWN_CHANCE){
            location.addActor(new SuspiciousAstronaut());
        }
    }
}