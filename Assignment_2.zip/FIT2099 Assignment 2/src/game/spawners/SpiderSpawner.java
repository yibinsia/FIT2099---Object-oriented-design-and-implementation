package game.spawners;

import edu.monash.fit2099.engine.positions.Location;
import game.actors.HuntsmanSpider;

import java.util.Random;
/**
 * Class implementing the Spawner interface for spawning Huntsman Spiders in a game.
 * Spiders are spawned at a specified location based on a probability check.
 */
public class SpiderSpawner implements Spawner {

    /**
     * The chance of a spider spawning at a given location during a spawn attempt.
     */
    private static final double SPAWN_CHANCE = 0.05;

    /**
     * Random number generator used to determine if a spider spawns.
     */
    private Random random = new Random();

    /**
     * Attempts to spawn a Huntsman Spider at a given location if the conditions are met.
     *
     * @param location The location where the spider might be spawned.
     *                 The location must not currently contain an actor for a spider to be spawned.
     */
    @Override
    public void spawn(Location location){
        if (!location.containsAnActor() && random.nextDouble() < SPAWN_CHANCE){
            location.addActor(new HuntsmanSpider());
        }
    }
}
